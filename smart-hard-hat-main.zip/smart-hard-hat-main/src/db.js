import Dexie from 'dexie';

// New database
export const db = new Dexie('SensorDatabase');

// Define the schema
// Table: sensor reading = column, query by timestamp
db.version(5).stores({
    readings: '++id, worker_id, timestamp, datetime, event, latitude, longitude, [worker_id+timestamp], [fall_detection+timestamp], [aqi_pm25_us+timestamp], [aqi_pm100_us+timestamp], [aqi_uba+timestamp], [noise_db+timestamp]'
}); 
