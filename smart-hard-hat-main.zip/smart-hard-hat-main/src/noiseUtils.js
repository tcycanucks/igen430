/**
 * Calculates NIOSH noise metrics.
 * Standard: 85dB Criterion, 3dB Exchange Rate.
 */
export const calculateNoiseMetrics = (rawReadings) => {

    if (!rawReadings || !Array.isArray(rawReadings) || rawReadings.length === 0) {
        return { dose: 0, projectedDose: 0, twa: 0, latest: 0, barActual: 0, barProjected: 0, buckets: [] };
    }

    // SELF-SORT: Ensure oldest-to-newest for math consistency
    const readings = [...rawReadings].sort((a, b) => a.timestamp - b.timestamp);

    //GET LATEST: The newest record (last index after sorting)
    const latestValue = readings[readings.length - 1].noise_db || 0;

    let totalDoseSum = 0;
    const FIVE_MIN_MS = 5 * 60 * 1000;
    const bucketData = {}; 

    readings.forEach((r, index) => {
        const level = Math.floor(r.noise_db || 0);
        if (level === 0) return;
        
        // RULE: 100dB+ represents a 5-second burst. 
        // Anything else represents the 5-minute interval.
        let contributingSeconds = 300;

        // RULE: For values 85-99, if a 100dB+ event happened in the same 5min window,
        // we subtract that burst time from the baseline to avoid double-counting.
        if (level >= 100) {
            contributingSeconds = 5;
        } else {
            const startTimeWindow = r.timestamp - FIVE_MIN_MS;
            let highNoiseCount = 0;
            // Look backward in time (lower indices in a sorted array)
            for (let i = index - 1; i >= 0; i--) {
                if (readings[i].timestamp < startTimeWindow) break;
                if ((readings[i].noise_db || 0) >= 100) highNoiseCount++;
            }
            contributingSeconds = Math.max(0, 300 - (5 * highNoiseCount));
        }


        const currentIntervalHours = contributingSeconds / 3600;

        if (level >= 85) {
            // NIOSH Formula for Allowed Time (T) in hours
            const allowedTime = 8 / Math.pow(2, (level - 85) / 3);
            totalDoseSum += (currentIntervalHours / allowedTime);

            const key = `${level} dBA`;
            if (!bucketData[key]) bucketData[key] = { actual: 0, allowed: allowedTime };
            bucketData[key].actual += currentIntervalHours;
        }
    });

    const dosePercent = totalDoseSum * 100;
    
    // TWA formula: $L = 10 \cdot \log_{10}(\frac{Dose}{100}) + 85$
    const twaValue = dosePercent > 0 ? (10 * Math.log10(dosePercent / 100) + 85) : 0;

    // Projection calculation
    const firstTs = readings[0].timestamp;
    const lastTs = readings[readings.length - 1].timestamp;

    // Use at least 5 mins to avoid division by zero/infinity
    const hoursElapsed = Math.max(FIVE_MIN_MS, (lastTs - firstTs)) / (1000 * 60 * 60);
    
    // Calculate 8-hour projection
    let projectedDose = (dosePercent / hoursElapsed) * 8;

    return {
        latest: latestValue,
        dose: dosePercent,
        projectedDose: projectedDose, 
        barActual: Math.min(dosePercent, 100),
        barProjected: Math.min(projectedDose, 100),
        twa: Number(twaValue), 
        buckets: [] 
    };
};