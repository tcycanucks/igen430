import './App.css'
import React, { useState, useEffect, useRef, createContext, useContext } from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import { MqttProvider, useMqtt } from './MqttContext';

// Pages
import Homepage from './0Homepage';
import WorkerInfo from './2WorkerInfo';

const Sidebar = () => {
  // Connection status
  const { status } = useMqtt();
  // State function to track if expanded (true) or collapsed (false)
  const [isExpanded, setIsExpanded] = useState(false);

  // Function to toggle the state
  const toggleSidebar = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className={`sidebar ${isExpanded ? 'expanded' : ''}`}>
      <nav className="sidebar-nav" style={{ paddingTop: '20px' }}>
        {/* Menu Icon */}
        <div onClick={toggleSidebar}>
          <SidebarItem icon={<svg 
            width="24" 
            height="24" 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg">
              <path d="M4 6H20M4 12H20M4 18H20" 
              stroke="white" 
              stroke-width="2" 
              stroke-linecap="round" 
              stroke-linejoin="round"/>
          </svg>} label={
            <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              Menu
              <span style={{width: '8px', height: '8px', borderRadius: '50%',
              backgroundColor: status === 'connected' ? '#4CAF50' : '#f44336', // Green if connected, Red otherwise
              display: isExpanded ? 'inline-block' : 'none' // Only show dot when sidebar is open
              }} />
            </span>
          } isExpanded={isExpanded}/>
        </div>
        {/* Dashboard Icon */}
        <Link to="/"><SidebarItem icon={
          <svg 
            width="20" 
            height="20" 
            viewBox="0 0 20 20" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg">
              <path 
              d="M19.4602 8.69904C19.4598 8.69858 19.4593 8.69812 19.4588 8.69766L11.3004 0.539551C10.9527 0.19165 10.4903 0 9.99855 0C9.50676 0 9.04442 0.191498 8.69652 0.539398L0.542379 8.69339C0.539632 8.69614 0.536886 8.69904 0.534139 8.70178C-0.179972 9.42001 -0.178751 10.5853 0.537649 11.3017C0.86495 11.6292 1.29723 11.8188 1.75942 11.8387C1.77819 11.8405 1.79711 11.8414 1.81618 11.8414H2.14135V17.8453C2.14135 19.0334 3.10799 20 4.29635 20H7.48818C7.81166 20 8.07412 19.7377 8.07412 19.4141V14.707C8.07412 14.1649 8.51509 13.7239 9.05724 13.7239H10.9399C11.482 13.7239 11.923 14.1649 11.923 14.707V19.4141C11.923 19.7377 12.1853 20 12.5089 20H15.7008C16.8891 20 17.8558 19.0334 17.8558 17.8453V11.8414H18.1573C18.6489 11.8414 19.1113 11.6499 19.4593 11.302C20.1765 10.5844 20.1768 9.41711 19.4602 8.69904Z" 
              fill="white"/> 
          </svg>} label="Dashboard" isExpanded={isExpanded} /></Link>

        {/* Worker Info Cards */}
        <Link to="/workers">
        <SidebarItem icon={<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3 3V21H21M21 3L15 4.5M14.113 6.65L16.884 10.345M16 12.5L11 14.5M7 15C7 15.5304 7.21071 16.0391 7.58579 16.4142C7.96086 16.7893 8.46957 17 9 17C9.53043 17 10.0391 16.7893 10.4142 16.4142C10.7893 16.0391 11 15.5304 11 15C11 14.4696 10.7893 13.9609 10.4142 13.5858C10.0391 13.2107 9.53043 13 9 13C8.46957 13 7.96086 13.2107 7.58579 13.5858C7.21071 13.9609 7 14.4696 7 15ZM11 5C11 5.53043 11.2107 6.03914 11.5858 6.41421C11.9609 6.78929 12.4696 7 13 7C13.5304 7 14.0391 6.78929 14.4142 6.41421C14.7893 6.03914 15 5.53043 15 5C15 4.46957 14.7893 3.96086 14.4142 3.58579C14.0391 3.21071 13.5304 3 13 3C12.4696 3 11.9609 3.21071 11.5858 3.58579C11.2107 3.96086 11 4.46957 11 5ZM16 12C16 12.5304 16.2107 13.0391 16.5858 13.4142C16.9609 13.7893 17.4696 14 18 14C18.5304 14 19.0391 13.7893 19.4142 13.4142C19.7893 13.0391 20 12.5304 20 12C20 11.4696 19.7893 10.9609 19.4142 10.5858C19.0391 10.2107 18.5304 10 18 10C17.4696 10 16.9609 10.2107 16.5858 10.5858C16.2107 10.9609 16 11.4696 16 12Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
} label="Worker Information Cards" isExpanded={isExpanded} /></Link>
      </nav>
    </div>
  );
};

// Navigation bar items
const SidebarItem = ({ icon, label, isExpanded }) => {
  return (
    <div className="sidebar-item">
      <div className="icon-wrapper">
        {icon} 
      </div>      
      <span className="item-label">
        {label}
      </span>
    </div>
  );
};

const App = () => {
  return (
    <MqttProvider>
      <div className='layout'>
        <Sidebar/>
          <main className="main-content">
            <Routes>
              <Route path="/" element={<Homepage />} />
              <Route path="/workers" element={<WorkerInfo />} />
            </Routes>
          </main>  
      </div>
    </MqttProvider>  
  );
};

export default App;
