// Map Locations

export const MAP_LOCATIONS = {
  "Select Location": {
      coords: [49.257183467101775, -123.14877765304632],
      zoom: 12,
    },  
  "Granville-14th Plaza": {
      coords: [49.25890361816513, -123.13849903128605],
      zoom: 22,
    },
    "LMP Student Housing Redevelopment – Phase 1": {
      coords: [49.26289511474371, -123.2561357700687], 
      zoom: 20,
    },
    "Oakridge Park": {
      coords: [49.232251660350485, -123.1178430404232],
      zoom: 17,
    },
    "Bute-Robson Plaza": {
      coords: [49.28590593697737, -123.1272678048173],
      zoom: 20,
    },
  };