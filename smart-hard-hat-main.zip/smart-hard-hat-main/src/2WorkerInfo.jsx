import React, { useRef, useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceArea, Legend } from 'recharts';import { db } from './db';
import { useLiveQuery } from 'dexie-react-hooks';
import { calculateNoiseMetrics } from './noiseUtils';

// OVERALL LAYOUT

const CardHeadingGroup = ({ subheading, heading }) => {
    return (
        <>
            <div>
                <div className="card-heading-container">
                    <p className="card-subheading">{subheading}</p>
                    <p className="card-heading">{heading}</p>
                </div>
            </div>
        </>
    );
}

// INACTIVITY CHECK

const useWorkerStatus = (workerId) => {
    return useLiveQuery(async () => {
        // Find the absolute latest reading for this worker
        const lastReading = await db.readings
            .where('[worker_id+timestamp]')
            .between([workerId, -Infinity], [workerId, Infinity])
            .reverse()
            .first();

        // If the worker has NO records in the database at all
        if (!lastReading) return { status: 'no-data', label: 'Never Seen' };

        const now = Date.now();
        const diffMs = now - lastReading.timestamp;
        const diffMins = Math.floor(diffMs / 60000);
        const diffSecs = Math.floor(diffMs / 1000);

        // Generate the "Time Ago" string
        let timeAgo = '';
        if (diffSecs < 60) {
            timeAgo = 'Just now';
        } else if (diffMins < 60) {
            timeAgo = `${diffMins}m ago`;
        } else {
            const diffHours = Math.floor(diffMins / 60);
            timeAgo = `${diffHours}h ago`;
        }

        const FIVE_MINUTES = 5 * 60 * 1000;

        if (lastReading.is_inactivity_filler || diffMs > FIVE_MINUTES) {
            return { status: 'offline', label: `Offline (${timeAgo})` };
        }

        return { status: 'online', label: `Online (${timeAgo})` };
    }, [workerId]);
};


// OVERALL CHECK
const ComplianceChecker = ({ workerId, type, onDateSelect }) => {
    const [daysRange, setDaysRange] = useState(7);
    const [result, setResult] = useState(null);
    const [calculating, setCalculating] = useState(false);

    const checkCompliance = async () => {
        setCalculating(true);
        try {
            // 1. Setup Timeframe (Last X days including today)
            const today = new Date();
            today.setHours(23, 59, 59, 999);
            
            const startDate = new Date();
            startDate.setDate(today.getDate() - (daysRange - 1));
            startDate.setHours(0, 0, 0, 0);
            const startTime = startDate.getTime();

            // 2. Fetch Data 
            const readings = await db.readings
                .where('worker_id').equals(workerId) 
                .filter(r => r.timestamp >= startTime)
                .toArray();

            // 3. Group by Local Date Key (YYYY-MM-DD)
            const daysMap = {};
            readings.forEach(r => {
                const d = new Date(r.timestamp);
                const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                if (!daysMap[dateKey]) daysMap[dateKey] = [];
                daysMap[dateKey].push(r);
            });

            const uiData = [];
            let violationsCount = 0;

            if (daysRange <= 30) {
                // DAILY VIEW (7D or 30D)
                for (let i = 0; i < daysRange; i++) {
                    const d = new Date(startDate);
                    d.setDate(startDate.getDate() + i);
                    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                    
                    // Format "Mar 11"
                    const displayDate = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
                    
                    const dayReadings = daysMap[key] || [];
                    let status = 'inactive';

                    if (dayReadings.length > 0) {
                        let isViolation = false;
                        if (type === 'air') {
                            const unhealthy = dayReadings.filter(r => 
                                (r.aqi_pm25_us >= 150) || (r.aqi_pm100_us >= 150) || (r.aqi_uba >= 3.5)
                            ).length;
                            isViolation = (unhealthy / dayReadings.length) > 0.5;
                        } else {
                            const mappedReadings = dayReadings.map(r => ({
                                timestamp: r.timestamp,
                                noise_db: r.noise_db || 0
                            }));
                            const dayMetrics = calculateNoiseMetrics(mappedReadings);
                            isViolation = parseFloat(dayMetrics.dose) >= 100;
                        }
                        status = isViolation ? 'violation' : 'compliant';
                        if (isViolation) violationsCount++;
                    }

                    uiData.push({
                        label: daysRange === 7 ? d.toLocaleDateString(undefined, { weekday: 'narrow' }) : d.getDate(),
                        displayDate: displayDate,
                        status,
                        id: key, // YYYY-MM-DD to pass to graphs
                    });
                }
            } else {
                // 6 MONTH VIEW
                for (let i = 5; i >= 0; i--) {
                    const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
                    const monthLabel = d.toLocaleDateString(undefined, { month: 'short' });
                    const yearMonthPrefix = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
                    
                    // Format "Jan '26"
                    const shortYear = d.toLocaleDateString(undefined, { year: '2-digit' });
                    const displayDate = `${monthLabel} '${shortYear}`;
                    
                    const monthDays = Object.keys(daysMap).filter(k => k.startsWith(yearMonthPrefix));
                    let status = 'inactive';
                    
                    if (monthDays.length > 0) {
                        const hasViolation = monthDays.some(date => {
                            const dayReadings = daysMap[date];
                            if (type === 'air') {
                                const unhealthy = dayReadings.filter(r => (r.aqi_pm25_us >= 150) || (r.aqi_uba >= 3.5)).length;
                                return (unhealthy / dayReadings.length) > 0.5;
                            } else {
                                return Math.max(...dayReadings.map(r => r.noise_dose || 0)) >= 100;
                            }
                        });
                        status = hasViolation ? 'violation' : 'compliant';
                        if (hasViolation) violationsCount++;
                    }
                    uiData.push({ 
                        label: monthLabel.charAt(0), 
                        displayDate: displayDate,
                        status, 
                        id: `${yearMonthPrefix}-01` // Passes the 1st of the month if clicked
                    });
                }
            }

            const activeDaysCount = uiData.filter(d => d.status !== 'inactive').length;
            setResult({ uiData, violationsCount, activeDaysCount, range: daysRange });
        } catch (err) {
            console.error("Compliance Check Failed:", err);
            setResult(null); 
        } finally {
            setCalculating(false);
        }
    };

    // Helper function for clicking a bubble
    const handleBubbleClick = (item) => {
        if (item.status !== 'inactive' && onDateSelect) {
            onDateSelect(item.id); // Passes "YYYY-MM-DD" up to the parent
        }
    };

    return (
        <div className="compliance-box" style={{ marginTop: '15px', borderTop: '1px solid #f1f5f9', paddingTop: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Historical Compliance
                </span>
                <div style={{ display: 'flex', gap: '6px' }}>
                    <select 
                        className="search-input"
                        value={daysRange} 
                        onChange={(e) => {
                            setDaysRange(Number(e.target.value));
                            setResult(null);
                        }}
                        style={{ fontSize: '0.7rem', padding: '2px 6px', width: 'auto', height: '24px' }}
                    >
                        <option value={7}>Last 7 Days</option>
                        <option value={30}>Last 30 Days</option>
                        {/* <option value={180}>Last 6 Months</option> */}
                    </select>
                    <button 
                        onClick={checkCompliance} 
                        disabled={calculating}
                        style={{ 
                            fontSize: '0.7rem', 
                            cursor: 'pointer', 
                            background: calculating ? '#cbd5e1' : '#3b82f6', 
                            color: 'white', 
                            border: 'none', 
                            borderRadius: '4px', 
                            padding: '0 10px',
                            height: '24px',
                            fontWeight: 'bold'
                        }}
                    >
                        {calculating ? '...' : 'RUN'}
                    </button>
                </div>
            </div>

            {result ? (
                <>
                    <div style={{ 
                        display: 'grid', 
                        // Adjusted grid to allow room for the date text underneath
                        gridTemplateColumns: result.range === 30 ? 'repeat(auto-fill, minmax(36px, 1fr))' : 'repeat(auto-fit, minmax(42px, 1fr))', 
                        gap: '8px 4px',
                        justifyContent: 'center',
                        marginBottom: '16px'
                    }}>
                        {result.uiData.map((item) => (
                            <div key={item.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                                <div 
                                    onClick={() => handleBubbleClick(item)}
                                    title={item.status !== 'inactive' ? `View data for ${item.displayDate}` : 'No data'}
                                    style={{
                                        width: result.range === 30 ? '24px' : '32px',
                                        height: result.range === 30 ? '24px' : '32px',
                                        borderRadius: '50%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        fontSize: '0.65rem',
                                        fontWeight: 'bold',
                                        border: item.status === 'inactive' ? '1px dashed #cbd5e1' : 'none',
                                        backgroundColor: item.status === 'compliant' ? '#22c55e' : item.status === 'violation' ? '#ef4444' : 'transparent',
                                        color: item.status === 'inactive' ? '#94a3b8' : 'white',
                                        // Added pointer cursor so users know it is clickable
                                        cursor: item.status !== 'inactive' ? 'pointer' : 'default',
                                        transition: 'transform 0.1s ease-in-out',
                                    }}
                                    // Slight hover effect inline
                                    onMouseEnter={(e) => { if(item.status !== 'inactive') e.currentTarget.style.transform = 'scale(1.1)'; }}
                                    onMouseLeave={(e) => { if(item.status !== 'inactive') e.currentTarget.style.transform = 'scale(1)'; }}
                                >
                                    {item.label}
                                </div>
                                {/* NEW: The Date Label Underneath */}
                                <span style={{ fontSize: '0.55rem', color: '#64748b', textAlign: 'center', whiteSpace: 'nowrap' }}>
                                    {item.displayDate}
                                </span>
                            </div>
                        ))}
                    </div>

                    {/* THE ONE-LINER SUMMARY */}
                    <div style={{ 
                        fontSize: '0.85rem', 
                        textAlign: 'center', 
                        padding: '8px', 
                        backgroundColor: result.violationsCount > 0 ? '#fff1f2' : '#f0fdf4',
                        borderRadius: '6px',
                        border: `1px solid ${result.violationsCount > 0 ? '#fecaca' : '#dcfce7'}`,
                        color: result.violationsCount > 0 ? '#991b1b' : '#166534',
                        fontWeight: '500'
                    }}>
                        {result.violationsCount > 0 ? (
                            <span>⚠️ Limits exceeded on {result.violationsCount} days.</span>
                        ) : result.activeDaysCount > 0 ? (
                            <span>✅ 100% compliant ({result.activeDaysCount} active days).</span>
                        ) : (
                            <span style={{ color: '#64748b' }}>⚪ No activity found for this period.</span>
                        )}
                    </div>
                </>
            ) : (
                <div style={{ fontSize: '0.7rem', color: '#94a3b8', textAlign: 'center', padding: '10px' }}>
                    Click RUN to analyze history
                </div>
            )}
        </div>
    );
};

// OFFLINE LAYOUT
// Custom Dot to render a solid filled circle if offline
const OfflineDot = (props) => {
    const { cx, cy, payload, offlineKey } = props;
    // Check if the specific offline key is true for this data point
    if (payload[offlineKey]) {
        return <circle cx={cx} cy={cy} r={4} fill="#64748b" stroke="#fff" strokeWidth={1.5} />;
    }
    return null; // Render nothing if it's a normal data point
};

// Custom Tooltip
const CustomTooltip = ({ active, payload, label, offlineKey }) => {
    if (active && payload && payload.length) {
        const isOffline = payload[0].payload[offlineKey];
        return (
            <div style={{ background: '#fff', border: '1px solid #e2e8f0', padding: '10px', borderRadius: '4px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}>
                <p style={{ margin: '0 0 5px 0', fontWeight: 'bold', fontSize: '11px', color: '#475569' }}>
                    {new Date(label).toLocaleString()}
                </p>
                {isOffline && (
                    <div style={{ padding: '4px 6px', backgroundColor: '#f1f5f9', borderRadius: '4px', marginBottom: '6px' }}>
                        <span style={{ fontSize: '10px', color: '#64748b', fontWeight: 'bold' }}>
                            ⚠️ Module Offline (Values reported as 0)
                        </span>
                    </div>
                )}
                {payload.map(entry => (
                    <p key={entry.name} style={{ margin: 0, fontSize: '11px', color: entry.color, fontWeight: '600' }}>
                        {entry.name}: {entry.value}
                    </p>
                ))}
            </div>
        );
    }
    return null;
};


// AIR

const AirQualityGraph = ({ workerId, workerName }) => {
    const [rangeType, setRangeType] = useState('1hour');
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [isExporting, setIsExporting] = useState(false);

    // NEW: States for the Export Date Pickers
    const [downloadStart, setDownloadStart] = useState(new Date().toISOString().split('T')[0]);
    const [downloadEnd, setDownloadEnd] = useState(new Date().toISOString().split('T')[0]);

    const getLocalDayRange = (dateString) => {
        const [year, month, day] = dateString.split('-').map(Number);
        const start = new Date(year, month - 1, day, 0, 0, 0, 0).getTime();
        const end = new Date(year, month - 1, day, 23, 59, 59, 999).getTime();
        return { start, end };
    };

    const handleDateFromCompliance = (dateString) => {
        setRangeType('day');
        setSelectedDate(dateString);
        // Optional: Smooth scroll back to the top of the graph
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const chartDomain = React.useMemo(() => {
        const now = Date.now();
        let start, end;
    
        switch (rangeType) {
            case '10min':
                start = now - 10 * 60 * 1000;
                end = now;
                break;
            case '1hour':
                start = now - 60 * 60 * 1000;
                end = now;
                break;
            case '8hour':
                start = now - 8 * 60 * 60 * 1000;
                end = now;
                break;
            case 'day':
                const range = getLocalDayRange(selectedDate);
                start = range.start;
                end = range.end;
                break;
            default: // 'all'
                return ['dataMin', 'dataMax']; 
        }
        return [start, end];
    }, [rangeType, selectedDate]);

    const data = useLiveQuery(async () => {
        const now = Date.now();
        let startTime = null;
        let endTime = now;
    
        if (rangeType === 'day') {
            const range = getLocalDayRange(selectedDate);
            startTime = range.start;
            endTime = range.end;
        } else if (rangeType !== 'all') {
            const offsets = { '10min': 10, '1hour': 60, '8hour': 480 };
            startTime = now - ((offsets[rangeType] || 60) * 60 * 1000);
        }
    
        let query = db.readings.where('worker_id').equals(workerId);
    if (startTime !== null) {
        query = query.filter(r => r.timestamp >= startTime && r.timestamp <= endTime);
    }

    const readings = await query.toArray();
    return readings.map(r => ({
        timestamp: r.timestamp,
        // pm25Aqi: r.aqi_pm25_us || 0,   // Renamed for clarity
        // pm10Aqi: r.aqi_pm100_us || 0,  // New PM 10 field
        // ubaAqi: r.aqi_uba || 0,
        pm25Aqi: r.aqi_pm25_us ?? null,   
        pm10Aqi: r.aqi_pm100_us ?? null,  
        ubaAqi: r.aqi_uba ?? null,
        is_air_offline: r.air_offline || r.is_inactivity_filler
    })).filter(r => r.pm25Aqi !== null || r.ubaAqi !== null);
}, [workerId, rangeType, selectedDate]) || [];

    // Calculate percentage of time in the "Danger Zones"
    // UBA >= 3.5 (Poor to Very Poor)
    // PM AQI >= 150 (Unhealthy to Hazardous)
    const airMetrics = React.useMemo(() => {
        if (!data || data.length === 0) {
            return { pm25: "0.0", pm10: "0.0", uba: "0.0", durationText: "0 min" };
        }

        let pm25Bad = 0;
        let pm10Bad = 0;
        let ubaBad = 0;

        data.forEach(r => {
            if (r.pm25Aqi >= 150) pm25Bad++;
            if (r.pm10Aqi >= 150) pm10Bad++;
            if (r.ubaAqi >= 3.5) ubaBad++;
        });

        // Calculate actual time span of the data currently displayed
        const firstTime = data[0].timestamp;
        const lastTime = data[data.length - 1].timestamp;
        const durationMs = lastTime - firstTime;
        
        let durationText = "0 min";
        if (durationMs > 0) {
            const hours = Math.floor(durationMs / (1000 * 60 * 60));
            const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
            if (hours > 0 && minutes > 0) {
                durationText = `${hours}h ${minutes}m`;
            } else if (hours > 0) {
                durationText = `${hours}h`;
            } else {
                durationText = `${minutes}m`;
            }
        } else if (data.length === 1) {
            durationText = "Instant"; // Only one data point exists
        }

        const total = data.length;
        return {
            pm25: ((pm25Bad / total) * 100).toFixed(1),
            pm10: ((pm10Bad / total) * 100).toFixed(1),
            uba: ((ubaBad / total) * 100).toFixed(1),
            durationText
        };
    }, [data]);

    // UPDATED: CSV Export Logic with Date Filtering
    const handleDownload = async () => {
        setIsExporting(true);
        try {
            const startTs = new Date(downloadStart).getTime();
            // End of day (23:59:59) for the end date
            const endTs = new Date(downloadEnd).getTime() + (24 * 60 * 60 * 1000) - 1;

            const readings = await db.readings
                .where('worker_id').equals(workerId)
                .filter(r => r.timestamp >= startTs && r.timestamp <= endTs)
                .toArray();

            if (readings.length === 0) {
                alert("No data found for the selected range.");
                return;
            }

            const headers = ["Timestamp", "Date", "PM 2.5 AQI", "PM 10 AQI", "UBA AQI"];
            const rows = readings.map(r => [
                r.timestamp,
                new Date(r.timestamp).toLocaleString(),
                r.aqi_pm25_us || 0,
                r.aqi_pm100_us || 0, // Added PM 10
                r.aqi_uba || 0
            ]);

            const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = `AQI_Data_${workerName || 'Worker'}_${downloadStart}_to_${downloadEnd}.csv`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error("Export failed:", error);
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div style={{ marginTop: '10px' }}>
            <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                marginBottom: '15px', 
                gap: '10px',
                flexWrap: 'wrap' 
            }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <select 
                        value={rangeType} 
                        onChange={(e) => setRangeType(e.target.value)} 
                        className="search-input" 
                        style={{ width: 'auto', padding: '4px 8px' }}
                    >
                        <option value="10min">Last 10 Minutes</option>
                        <option value="1hour">Last 1 Hour</option>
                        <option value="8hour">Last 8 Hours</option>
                        <option value="day">Select Specific Day</option>
                        <option value="all">All Time</option>
                    </select>

                    {rangeType === 'day' && (
                        <input 
                            type="date" 
                            value={selectedDate} 
                            onChange={(e) => setSelectedDate(e.target.value)} 
                            className="search-input"
                            style={{ padding: '3px 8px' }}
                        />
                    )}
                </div>

                <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '8px', 
                    padding: '8px', 
                    backgroundColor: '#f8fafc', 
                    borderRadius: '6px', 
                    border: '1px solid #e2e8f0' 
                }}>
                    <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#64748b' }}>EXPORT:</span>
                    <input 
                        type="date" 
                        value={downloadStart} 
                        onChange={(e) => setDownloadStart(e.target.value)} 
                        className="search-input"
                        style={{ padding: '2px 4px', fontSize: '11px' }}
                    />
                    <span style={{ fontSize: '11px' }}>to</span>
                    <input 
                        type="date" 
                        value={downloadEnd} 
                        onChange={(e) => setDownloadEnd(e.target.value)} 
                        className="search-input"
                        style={{ padding: '2px 4px', fontSize: '11px' }}
                    />
                    <button 
                        onClick={handleDownload}
                        disabled={isExporting}
                        style={{
                            padding: '4px 12px',
                            backgroundColor: '#2563eb',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            fontSize: '11px',
                            fontWeight: 'bold',
                            cursor: isExporting ? 'not-allowed' : 'pointer',
                            opacity: isExporting ? 0.7 : 1
                        }}
                    >
                        {isExporting ? '...' : 'Download CSV'}
                    </button>
                </div>
            </div>
            {/* Main Layout: Graph (Left) & Bars (Right) */}
            <div style={{ display: 'flex', gap: '15px', height: '460px', alignItems: 'stretch' }}>
                
                {/* Expanded Graph Container */}
                <div style={{ 
                    flex: '1', 
                    background: '#fff', 
                    padding: '15px', 
                    borderRadius: '8px', 
                    border: '1px solid #e0e7ff',
                    minWidth: '700px'
                }}>
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data} margin={{ top: 20, right: 15, left: 15, bottom: 20 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                                dataKey="timestamp" 
                                type="number" 
                                domain={(() => {
                                    const now = Date.now();
                                    if (rangeType === '10min') return [now - 600000, now];
                                    if (rangeType === '1hour') return [now - 3600000, now];
                                    if (rangeType === '8hour') return [now - 28800000, now];
                                    if (rangeType === 'day' || rangeType === 'all') return ['dataMin', 'dataMax'];
                                    return ['dataMin', 'dataMax'];
                                })()}
                                tickFormatter={(t) => rangeType === 'all' 
                                    ? new Date(t).toLocaleDateString([], {month:'short', day:'numeric'})
                                    : new Date(t).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}
                                fontSize={10}
                            />
                            
                            <YAxis yAxisId="left" orientation="left" domain={[1, 5]} ticks={[1,2,3,4,5]} fontSize={10} stroke="#10b981" label={{ value: 'UBA AQI', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#10b981', fontWeight: 'bold' }, offset: 0}} />
                            <YAxis yAxisId="right" orientation="right" domain={[0, 400]} fontSize={10} stroke="#3b82f6" label={{ value: 'PM AQI', angle: 90, position: 'insideRight', style: { fill: '#3b82f6', fontWeight: 'bold' } }} />

                            <ReferenceArea yAxisId="left" y1={0} y2={1.5} fill="#22c55e" fillOpacity={0.05} label={{ value: '1: Excellent', position: 'insideLeft', fontSize: 8, fill: '#166534' }} />
                            <ReferenceArea yAxisId="left" y1={1.5} y2={2.5} fill="#84cc16" fillOpacity={0.05} label={{ value: '2: Good', position: 'insideLeft', fontSize: 8, fill: '#3f6212' }} />
                            <ReferenceArea yAxisId="left" y1={2.5} y2={3.5} fill="#eab308" fillOpacity={0.05} label={{ value: '3: Moderate', position: 'insideLeft', fontSize: 8, fill: '#854d0e' }} />
                            <ReferenceArea yAxisId="left" y1={3.5} y2={4.5} fill="#f97316" fillOpacity={0.05} label={{ value: '4: Poor', position: 'insideLeft', fontSize: 8, fill: '#9a3412' }} />
                            <ReferenceArea yAxisId="left" y1={4.5} y2={5} fill="#ef4444" fillOpacity={0.1} label={{ value: '5: Unhealthy', position: 'insideLeft', fontSize: 8, fill: '#991b1b' }} />

                            <ReferenceArea yAxisId="right" y1={0} y2={50} fill="#22c55e" fillOpacity={0.02} label={{ value: 'Good', position: 'insideRight', fontSize: 8, fill: '#166534' }} />
                            <ReferenceArea yAxisId="right" y1={50} y2={100} fill="#eab308" fillOpacity={0.02} label={{ value: 'Moderate', position: 'insideRight', fontSize: 8, fill: '#854d0e' }} />
                            <ReferenceArea yAxisId="right" y1={100} y2={150} fill="#f97316" fillOpacity={0.05} label={{ value: 'Sensitive Groups', position: 'insideRight', fontSize: 8, fill: '#9a3412' }} />
                            <ReferenceArea yAxisId="right" y1={150} y2={200} fill="#ef4444" fillOpacity={0.05} label={{ value: 'Unhealthy', position: 'insideRight', fontSize: 8, fill: '#991b1b' }} />
                            <ReferenceArea yAxisId="right" y1={200} y2={300} fill="#a855f7" fillOpacity={0.05} label={{ value: 'Very Unhealthy', position: 'insideRight', fontSize: 8, fill: '#6b21a8' }} />
                            <ReferenceArea yAxisId="right" y1={300} y2={400} fill="#7f1d1d" fillOpacity={0.1} label={{ value: 'Hazardous', position: 'insideRight', fontSize: 8, fill: '#450a0a' }} />

                            <Tooltip content={<CustomTooltip offlineKey="is_air_offline" />} />
                            <Legend verticalAlign="bottom" height={36} wrapperStyle={{ paddingTop: '20px' }} />
                            <Line yAxisId="right" type="monotone" dataKey="pm25Aqi" stroke="#3b82f6" dot={<OfflineDot offlineKey="is_air_offline" />} strokeWidth={2} name="PM 2.5 AQI" isAnimationActive={false} />
                            <Line yAxisId="right" type="monotone" dataKey="pm10Aqi" stroke="#06b6d4" dot={<OfflineDot offlineKey="is_air_offline" />} strokeWidth={2} strokeDasharray="5 5" name="PM 10 AQI" isAnimationActive={false} />
                            <Line yAxisId="left" type="stepAfter" dataKey="ubaAqi" stroke="#10b981" dot={<OfflineDot offlineKey="is_air_offline" />} strokeWidth={2} name="UBA AQI" isAnimationActive={false} />
                            
                            </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Vertical Exposure Sidebar */}
                <div style={{ 
                    width: '160px', 
                    display: 'flex', 
                    color: 'black',
                    flexDirection: 'column', 
                    padding: '15px 10px', 
                    backgroundColor: '#f8fafc', 
                    borderRadius: '8px', 
                    border: '1px solid #e2e8f0',
                    textAlign: 'center'
                }}>
                    <div style={{ marginBottom: '12px' }}>
                        <p style={{ fontSize: '10px', fontWeight: 'bold', lineHeight: '1.2', margin: 0 }}>
                            % TIME IN<br/>UNHEALTHY ZONE
                        </p>
                        <p style={{ fontSize: '9px', marginTop: '4px', margin: '4px 0 0 0' }}>
                            (of {airMetrics.durationText} period)
                        </p>
                    </div>
                    
                    {/* Meters Container */}
                    <div style={{ flex: '1', display: 'flex', justifyContent: 'space-around', gap: '10px', alignItems: 'stretch' }}>
                        
                        {/* PM 2.5 Meter */}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
                            <div style={{ flex: 1, width: '20px', backgroundColor: '#e2e8f0', borderRadius: '10px', position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column-reverse' }}>
                                <div style={{ height: `${airMetrics.pm25}%`, width: '100%', backgroundColor: '#ef4444', transition: 'height 0.4s ease-out' }} />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                                <span style={{ fontSize: '9px', fontWeight: 'bold', color: '#64748b' }}>PM 2.5</span>
                                <span style={{ fontSize: '10px', fontWeight: 'bold', color: '#1e293b' }}>{airMetrics.pm25}%</span>
                            </div>
                        </div>

                        {/* PM 10 Meter */}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
                            <div style={{ flex: 1, width: '20px', backgroundColor: '#e2e8f0', borderRadius: '10px', position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column-reverse' }}>
                                <div style={{ height: `${airMetrics.pm10}%`, width: '100%', backgroundColor: '#ef4444', transition: 'height 0.4s ease-out' }} />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                                <span style={{ fontSize: '9px', fontWeight: 'bold', color: '#64748b' }}>PM 10</span>
                                <span style={{ fontSize: '10px', fontWeight: 'bold', color: '#1e293b' }}>{airMetrics.pm10}%</span>
                            </div>
                        </div>

                        {/* UBA Meter */}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
                            <div style={{ flex: 1, width: '20px', backgroundColor: '#e2e8f0', borderRadius: '10px', position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column-reverse' }}>
                                <div style={{ height: `${airMetrics.uba}%`, width: '100%', backgroundColor: '#ef4444', transition: 'height 0.4s ease-out' }} />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                                <span style={{ fontSize: '9px', fontWeight: 'bold', color: '#64748b' }}>UBA</span>
                                <span style={{ fontSize: '10px', fontWeight: 'bold', color: '#1e293b' }}>{airMetrics.uba}%</span>
                            </div>
                        </div>
                    </div>

                    {/* Explainer Text */}
                    <div style={{ 
                        marginTop: '12px', 
                        paddingTop: '8px', 
                        borderTop: '1px solid #fecaca', 
                        fontSize: '9px', 
                        textAlign: 'left', 
                        lineHeight: '1.4' 
                    }}>
                        <strong>Danger Thresholds (alert triggered when more than 50% of time spent in unhelathy region):</strong><br/>
                        PM AQI &ge; 150<br/>
                        UBA AQI &ge; 4
                    </div>
                </div>
            </div>

            <ComplianceChecker 
                workerId={workerId} 
                type="air" 
                onDateSelect={handleDateFromCompliance} 
            />
        </div>
    );
};

const CardAirQuality = ({ subheading, id, name }) => {
    return (
        <div className="metric-container-shared">
            <p className="card-subheading" style={{ marginBottom: '12px' }}>{subheading}</p>
            <AirQualityGraph workerId={id} workerName={name} />
        </div>
    );
};

// NOISE

const NoiseGraph = ({ workerId, workerName }) => {
    // Default to a preset
    const [rangeType, setRangeType] = useState('1hour');
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [isExplainOpen, setIsExplainOpen] = useState(false);

    const [downloadStart, setDownloadStart] = useState(new Date().toISOString().split('T')[0]);
    const [downloadEnd, setDownloadEnd] = useState(new Date().toISOString().split('T')[0]);
    const [isExporting, setIsExporting] = useState(false);

    const getLocalDayRange = (dateString) => {
        // Splits "YYYY-MM-DD" and creates a local date object
        const [year, month, day] = dateString.split('-').map(Number);
        const start = new Date(year, month - 1, day, 0, 0, 0, 0).getTime();
        const end = new Date(year, month - 1, day, 23, 59, 59, 999).getTime();
        return { start, end };
    };

    const handleDateFromCompliance = (dateString) => {
        setRangeType('day');
        setSelectedDate(dateString);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const chartDomain = React.useMemo(() => {
        const now = Date.now();
        let start, end;
    
        switch (rangeType) {
            case '10min':
                start = now - 10 * 60 * 1000;
                end = now;
                break;
            case '1hour':
                start = now - 60 * 60 * 1000;
                end = now;
                break;
            case '8hour':
                start = now - 8 * 60 * 60 * 1000;
                end = now;
                break;
            case 'day':
                const range = getLocalDayRange(selectedDate);
                start = range.start;
                end = range.end;
                break;
            default: // 'all'
                return ['dataMin', 'dataMax']; 
        }
        return [start, end];
    }, [rangeType, selectedDate]);


    const data = useLiveQuery(async () => {
        const now = Date.now();
        let startTime = null;
        let endTime = now;
    
        if (rangeType === 'day') {
            const range = getLocalDayRange(selectedDate);
            startTime = range.start;
            endTime = range.end;
        } else if (rangeType !== 'all') {
            const offsets = { '10min': 10, '1hour': 60, '8hour': 480 };
            startTime = now - ((offsets[rangeType] || 60) * 60 * 1000);
        }
    
        let query = db.readings.where('worker_id').equals(workerId);

        if (startTime !== null) {
            query = query.filter(r => r.timestamp >= startTime && r.timestamp <= endTime);
        }
    
        const readings = await query.toArray();
        return readings.map(r => ({
            timestamp: r.timestamp,
            noise_db: r.noise_db,
            is_noise_offline: r.noise_offline || r.is_inactivity_filler
        }));
    }, [workerId, rangeType, selectedDate]) || [];

    const metrics = React.useMemo(() => {
        // If All Time is selected, return a "N/A" state
        if (rangeType === 'all') {
            return { 
                dose: "N/A", 
                projectedDose: "N/A", 
                barActual: 0, 
                barProjected: 0, 
                twa: "N/A", 
                buckets: [] 
            };
        }
        // Otherwise, calculate normally
        return calculateNoiseMetrics(data);
    }, [data, rangeType]); // Added rangeType to dependencies


    // CSV Export Logic
    const handleDownload = async () => {
        setIsExporting(true);
        try {
            const startTs = new Date(downloadStart).getTime();
            // End of the day for the end date
            const endTs = new Date(downloadEnd).getTime() + (24 * 60 * 60 * 1000) - 1;

            const readings = await db.readings
                .where('worker_id').equals(workerId)
                .filter(r => r.timestamp >= startTs && r.timestamp <= endTs)
                .toArray();

            if (readings.length === 0) {
                alert("No data found for the selected range.");
                return;
            }

            // Create CSV Content
            const headers = ["Timestamp", "Date", "Noise_dBA"];
            const rows = readings.map(r => [
                r.timestamp,
                new Date(r.timestamp).toLocaleString(),
                r.noise_db
            ]);

            const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
            
            // Trigger Download
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.setAttribute("href", url);
            link.setAttribute("download", `Noise_Data_${workerName || 'Worker'}_${downloadStart}_to_${downloadEnd}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error("Export failed:", error);
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div style={{ marginTop: '10px' }}>
            {/* 1. Controls Bar */}
            <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                marginBottom: '15px', 
                gap: '10px',
                flexWrap: 'wrap' 
            }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <select 
                        value={rangeType} 
                        onChange={(e) => setRangeType(e.target.value)} 
                        className="search-input" 
                        style={{ width: 'auto', padding: '4px 8px' }}
                    >
                        <option value="10min">Last 10 Minutes</option>
                        <option value="1hour">Last 1 Hour</option>
                        <option value="8hour">Last 8 Hours</option>
                        <option value="day">Select Specific Day</option>
                        <option value="all">All Time</option>
                    </select>

                    {rangeType === 'day' && (
                        <input 
                            type="date" 
                            value={selectedDate} 
                            onChange={(e) => setSelectedDate(e.target.value)} 
                            className="search-input"
                            style={{ padding: '3px 8px' }}
                        />
                    )}
                </div>

                {/* DOWNLOAD SECTION */}
                <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '8px', 
                    padding: '8px', 
                    backgroundColor: '#f8fafc', 
                    borderRadius: '6px', 
                    border: '1px solid #e2e8f0' 
                }}>
                    <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#64748b' }}>EXPORT:</span>
                    <input 
                        type="date" 
                        value={downloadStart} 
                        onChange={(e) => setDownloadStart(e.target.value)} 
                        className="search-input"
                        style={{ padding: '2px 4px', fontSize: '11px' }}
                    />
                    <span style={{ fontSize: '11px' }}>to</span>
                    <input 
                        type="date" 
                        value={downloadEnd} 
                        onChange={(e) => setDownloadEnd(e.target.value)} 
                        className="search-input"
                        style={{ padding: '2px 4px', fontSize: '11px' }}
                    />
                    <button 
                        onClick={handleDownload}
                        disabled={isExporting}
                        style={{
                            padding: '4px 12px',
                            backgroundColor: '#2563eb',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            fontSize: '11px',
                            fontWeight: 'bold',
                            cursor: isExporting ? 'not-allowed' : 'pointer',
                            opacity: isExporting ? 0.7 : 1
                        }}
                    >
                        {isExporting ? '...' : 'Download CSV'}
                    </button>
                </div>
            </div>

            {/* 2. Main Layout: Graph (Left) & Dose (Right) */}
            <div style={{ display: 'flex', gap: '15px', height: '460px', alignItems: 'stretch' }}>
                
                {/* Expanded Graph Container */}
                <div style={{ 
                    flex: '1', 
                    background: '#fff', 
                    padding: '15px', 
                    height: '400px',
                    borderRadius: '8px', 
                    border: '1px solid #e0e7ff',
                    minWidth: '640px'
                }}>
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart 
                            data={data.length > 0 ? data : [{}]}
                            margin={{ top: 5, right: 5, left: -20, bottom: 0 }}
                        >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                                dataKey="timestamp" 
                                type="number" 
                                domain={(() => {
                                    const now = Date.now();
                                    if (rangeType === '10min') return [now - 600000, now];
                                    if (rangeType === '1hour') return [now - 3600000, now];
                                    if (rangeType === '8hour') return [now - 28800000, now];
                                    if (rangeType === 'day') {
                                        // const d = new Date(selectedDate);
                                        // return [d.setHours(0,0,0,0), d.setHours(23,59,59,999)];
                                        return ['dataMin', 'dataMax'];
                                    }
                                    return ['dataMin', 'dataMax'];
                                })()}
                                tickFormatter={(t) => {
                                    const date = new Date(t);
                                    if (rangeType === 'all') {
                                        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
                                    }
                                    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                                }}
                                fontSize={12}
                            />
                            <YAxis domain={[0, 140]} fontSize={12} />
                            <Tooltip content={<CustomTooltip offlineKey="is_noise_offline" />} />
                                

                            {/* Caution Zone: 85 - 120 dBA (Light Orange) */}
                            <ReferenceArea 
                                y1={85} 
                                y2={120} fill="#f97316" 
                                fillOpacity={0.1} 
                                label={{ 
                                    value: '85 dBA: Damage Accumulation Begins', 
                                    position: 'insideBottomRight', 
                                    fill: '#c2410c', 
                                    fontSize: 10,
                                    fontWeight: 'bold',
                                    offset: 10
                                }}
                            />
        
                            {/* Danger Zone: 120 - 140+ dBA (Light Red) */}
                            <ReferenceArea 
                                y1={120} y2={140} fill="#ef4444" 
                                fillOpacity={0.1} 
                                label={{ 
                                    value: '120 dBA: Instant Damage Begins', 
                                    position: 'insideBottomRight', 
                                    fill: '#991b1b', 
                                    fontSize: 10,
                                    fontWeight: 'bold',
                                    offset: 10
                                }}
                            />

                            <ReferenceArea y1={85} y2={120} fill="#f97316" fillOpacity={0.1} />

                            <Line 
                                type="monotone" 
                                dataKey="noise_db" 
                                stroke="#ef4444" 
                                dot={<OfflineDot offlineKey="is_noise_offline" />} 
                                strokeWidth={2} 
                                isAnimationActive={false} 
                            />          
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Vertical Dose Sidebar */}
                <div style={{ 
                    width: '120px', 
                    display: 'flex', 
                    flexDirection: 'column', 
                    padding: '15px 10px', 
                    backgroundColor: '#f0f4ff', 
                    borderRadius: '8px', 
                    border: '1px solid #e0e7ff',
                    textAlign: 'center'
                }}>
                    <p style={{ fontSize: '10px', fontWeight: 'bold', color: '#64748b', marginBottom: '12px' }}>EXPOSURE</p>
                    
                    {/* Meters Container */}
                    <div style={{ flex: '1', display: 'flex', justifyContent: 'center', gap: '15px', alignItems: 'stretch' }}>
                        
                        {/* Actual Meter */}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
                            <div style={{ flex: 1, width: '20px', backgroundColor: '#cbd5e1', borderRadius: '10px', position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column-reverse' }}>
                                <div style={{ 
                                    height: `${metrics.barActual}%`, 
                                    width: '100%', 
                                    backgroundColor: metrics.barActual >= 100 ? '#ef4444' : '#22c55e',
                                    transition: 'height 0.4s ease-out'
                                }} />
                            </div>
                            <span style={{ fontSize: '9px', fontWeight: 'bold', color: '#64748b' }}>ACTUAL</span>
                        </div>

                        {/* Projected Meter */}
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
                            <div style={{ flex: 1, width: '20px', backgroundColor: '#cbd5e1', borderRadius: '10px', position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column-reverse' }}>
                                <div style={{ 
                                    height: `${metrics.barProjected}%`, 
                                    width: '100%', 
                                    backgroundColor: metrics.barProjected >= 100 ? '#f97316' : '#94a3b8',
                                    transition: 'height 0.4s ease-out'
                                }} />
                            </div>
                            <span style={{ fontSize: '9px', fontWeight: 'bold', color: '#64748b' }}>PROJECTED</span>
                        </div>
                    </div>
                    
                    {/* Text Data Summary */}
                    <div style={{ marginTop: '15px', borderTop: '1px solid #e0e7ff', paddingTop: '10px' }}>
                        <div style={{ fontSize: '16px', fontWeight: '800', color: '#1e293b' }}>
                            {/* Only add % if it's a number */}
                            {metrics.dose !== "N/A" ? Math.round(metrics.dose) : "N/A"}%
                        </div>
                        <div style={{ fontSize: '10px', color: '#64748b' }}>
                            Projected Total Dose: {metrics.projectedDose !== "N/A" ? Math.round(metrics.projectedDose) : "N/A"}%
                        </div>
                        <div style={{ fontSize: '12px', fontWeight: 'bold', color: '#334155', marginTop: '4px' }}>
                            Time Weighted Average: {metrics.twa !== "N/A" ? Math.round(metrics.twa) : "N/A"} {metrics.twa !== "N/A" ? "dBA" : ""}
                        </div>
                    </div>
                </div>
            </div>

            {/* Explanation Toggle */}
            <button 
                onClick={() => setIsExplainOpen(!isExplainOpen)} 
                style={{ marginTop: '12px', fontSize: '11px', background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', display: 'block' }}
            >
                {isExplainOpen ? '▼ Hide OSHA Formula' : '▶ How is this calculated?'}
            </button>
            {isExplainOpen && (
                <div style={{ fontSize: '10px', color: '#94a3b8', marginTop: '5px', lineHeight: '1.4' }}>
                    Calculated using NIOSH Standard: 3dB exchange rate, 85dB Criterion Level (REL).
                </div>
            )}
            <ComplianceChecker 
                workerId={workerId} 
                type="noise" 
                onDateSelect={handleDateFromCompliance} 
            />
        </div>
    );
};

const CardNoise = ({ subheading, workerId, workerName }) => {
    return (
        <div className="metric-container-shared">
            <p className="card-subheading" style={{ marginBottom: '12px' }}>{subheading}</p>
            <NoiseGraph workerId={workerId} workerName={workerName} />
        </div>
    );
};


// Overall
const WorkerCard = (worker) => { 
    const {
        name, id, photoUrl, role, gpsLocation, phoneNumber, crewLead, 
        // noiseNum, noiseRisk, noiseNumAve, noiseRiskAve, 
        // fallDetection, 
        // pm25Num, pm25Qual, pm10Num, pm10Qual, co2Num, co2Qual, tvocNum, tvocQual, ubaNum, ubaQual
    } = worker;

    // Get live status (online, offline, or no-data)
    const statusData = useWorkerStatus(id) || { status: 'no-data', label: 'Loading...' };

    const currentStatus = statusData.status || 'no-data';
    const statusLabel = currentStatus.replace('-', ' ');

    return (
        <div className="card-container" style={{ display: 'flex', flexDirection: 'row', gap: '20px' }}>
        
            
            <div style={{ flex: '0 0 100px', borderRight: '1px solid #e2e8f0', paddingRight: '20px' }}>
                <div className="profile-photo-container" style={{ marginBottom: '15px' }}>
                    <img src={photoUrl || 'placeholder.png'} className="profile-photo" alt="profile" />
                </div>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    
            
                    <CardHeadingGroup subheading="Worker" heading={name}/>
                    <CardHeadingGroup subheading="ID" heading={id}/>
                    <CardHeadingGroup subheading="Role" heading={role}/>
                    
                    {/* <hr style={{ border: 'none', borderTop: '1px solid #f1f5f9', margin: '10px 0' }} /> */}
                    {/* <CardHeadingGroup subheading="GPS" heading={gpsLocation}/> */}
                    <CardHeadingGroup subheading="Lead" heading={crewLead}/>

                    {/* Status Badge Offline/Online */}
                    <div className={`status-badge status-${statusData.status}`}>
                        <span className="status-dot" />
                        {statusData.label}
                    </div>

                    
                </div>
                
            </div>

            <div style={{ 
                flex: '1', 
                display: 'grid', 
                gridTemplateColumns: '1fr 1.5fr 2fr', // Adjust ratios based on content width
                gap: '20px' 
            }}>
                {/* Column 1: Fall/Impact */}
                {/* <div style={{ minWidth: 0 }}>
                    {/* <CardFall subheading="Fall/Impact Monitoring" fallDetection={fallDetection}/> 
                </div> */}

                {/* Column 2: Air Quality */}
                <div style={{ borderLeft: '1px solid #f1f5f9', paddingLeft: '15px' }}>
                    <CardAirQuality subheading="Air Quality Monitoring" {...worker} />
                </div>

                {/* Column 3: Noise Level */}
                <div style={{ borderLeft: '1px solid #f1f5f9', paddingLeft: '15px' }}>
                    <CardNoise subheading="Noise Level Monitoring" workerId={id} workerName={name} />                </div>
            </div>
        </div>
    );
};

const WorkerInfo = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [showDropdown, setShowDropdown] = useState(false);

    const workers = [
        {
            id: 1,
            name: "Overworked Otter",
            role: "Labourer",
            photoUrl: "/images/otter.webp",
            gpsLocation: "49.233180, -123.121372" ,
            phoneNumber: "778-667-5613",
            crewLead: "Cheetah InCharge",

            pm25Num: 8, pm25Qual: "Good",
            pm10Num: 15, pm10Qual: "Good",
            co2Num: 650, co2Qual: "Good",
            tvocNum: 120, tvocQual: "Good",
            ubaNum: 1, ubaQual: "Excellent",

            noiseNum: "90", 
            noiseRisk: "At risk", 
            noiseNumAve: "20", 
            noiseRiskAve: "No risk", 

            fallDetection: false,
        },
        {
            id: 2,
            name: "Grey Wolf Del Grind",
            role: "Labourer", 
            photoUrl: "/images/wolf.png",
            gpsLocation: "49.233180, -123.121372" ,
            phoneNumber: "778-667-5613",
            crewLead: "Cheetah InCharge",

            pm25Num: 12, pm25Qual: "Good",
            pm10Num: 20, pm10Qual: "Good",
            co2Num: 1450, co2Qual: "Unhealthy", // Triggers Red (Custom Scale)
            tvocNum: 450, tvocQual: "Of Concern", // Triggers Orange (Custom Scale)
            ubaNum: 3, ubaQual: "Moderate", // Triggers Yellow (UBA Scale)

            noiseNum: "90", 
            noiseRisk: "At risk", 
            noiseNumAve: "20", 
            noiseRiskAve: "No risk", 

            fallDetection: false,
        },
        {
            id: 3,
            name: "Lynx LeLongNight",
            role: "Labourer", 
            photoUrl: "/images/lynx.png",
            gpsLocation: "49.233180, -123.121372" ,
            phoneNumber: "778-667-5613",
            crewLead: "Cheetah InCharge",
            pm25Num: 45, pm25Qual: "Unhealthy for sensitive groups", // Triggers Orange (EPA Scale)
            pm10Num: 80, pm10Qual: "Moderate",
            co2Num: 800, co2Qual: "Good",
            tvocNum: 150, tvocQual: "Good",
            ubaNum: 4, ubaQual: "Poor", // Triggers Orange (UBA Scale)

            noiseNum: "90", 
            noiseRisk: "At risk", 
            noiseNumAve: "20", 
            noiseRiskAve: "No risk", 

            fallDetection: true,
        },

        {
            id: 4,
            name: "Narwhal Nosleep",
            role: "Labourer", 
            photoUrl: "/images/narwhal.png",
            gpsLocation: "49.233180, -123.121372" ,
            phoneNumber: "778-667-5613",
            crewLead: "Cheetah InCharge",
            pm25Num: 100, pm25Qual: "Hazardous", 
            pm10Num: 800, pm10Qual: "Very unhealthy",
            co2Num: 1000, co2Qual: "Of concern",
            tvocNum: 2000, tvocQual: "Good",
            ubaNum: 4, ubaQual: "Good",
            
            noiseNum: "90", 
            noiseRisk: "At risk", 
            noiseNumAve: "20", 
            noiseRiskAve: "No risk", 

            fallDetection: true,
        },
        {
            id: 10,
            name: "Fake Person",
            role: "Labourer", 
            photoUrl: "/images/constructionworker.png",
            gpsLocation: "49.233180, -123.121372" ,
            phoneNumber: "778-667-5613",
            crewLead: "Cheetah InCharge",
            // FOR INITIAL TESTING
            // pm25Num: 100, pm25Qual: "Hazardous", 
            // pm10Num: 800, pm10Qual: "Very unhealthy",
            // co2Num: 1000, co2Qual: "Of concern",
            // tvocNum: 2000, tvocQual: "Good",
            // ubaNum: 4, ubaQual: "Good",
            // noiseNum: "90", 
            // noiseRisk: "At risk", 
            // noiseNumAve: "20", 
            // noiseRiskAve: "No risk", 
            // fallDetection: true,
        }
    ];

    // Filter logic for search bar
    const filteredWorkers = workers.filter(worker => 
        worker.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        worker.id.toString().includes(searchTerm)
    );

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
        setShowDropdown(true); // Show dropdown when typing
    };

    const handleSelectWorker = (name) => {
        setSearchTerm(name); // Fill input with name
        setShowDropdown(false); // Hide dropdown
    };

    useEffect(() => {
        const handleClickOutside = () => setShowDropdown(false);
        window.addEventListener('click', handleClickOutside);
        return () => window.removeEventListener('click', handleClickOutside);
    }, []);

    return (
        <div className="dashboard-page">
            <h1>Worker Info</h1>

            {/*  SEARCH SECTION */}
            <div style={{ marginBottom: '20px' }}>
                <div className="search-container" onClick={(e) => e.stopPropagation()}>
                    <input 
                        type="text" 
                        placeholder="Search Worker Name or ID..." 
                        value={searchTerm}
                        onChange={handleSearchChange}
                        onFocus={() => setShowDropdown(true)}
                        className="search-input"
                    />
                    
                    {/* Dropdown Logic */}
                    {showDropdown && searchTerm && (
                        <ul className="search-dropdown">
                            {filteredWorkers.length > 0 ? (
                                filteredWorkers.map(w => (
                                    <li 
                                        key={w.id} 
                                        onClick={() => handleSelectWorker(w.name)}
                                        className="search-item"
                                    >
                                        <span style={{ fontWeight: 500 }}>{w.name}</span>
                                        <span className="search-match-info">ID: {w.id}</span>
                                    </li>
                                ))
                            ) : (
                                <li className="search-item" style={{ cursor: 'default', color: '#94a3b8' }}>
                                    No workers found
                                </li>
                            )}
                        </ul>
                    )}
                </div>
            </div>

            <div className="dashboard-frame">
                <div className="dashboard-wrapper">
                    {filteredWorkers.map((worker, index) => (
                        <WorkerCard key={index} {...worker} />
                    ))}
                </div>
            </div>
        </div>
    )
};

export default WorkerInfo;