import React, { useState, useEffect, useRef, createContext, useContext } from 'react';
import mqtt from 'mqtt';
import { db } from './db';

const MqttContext = createContext();

// BROKER AND TOPIC INFO
// FOR PREVIOUS WEBCLIENT TESTING PURPOSES:
// const MQTT_BROKER_URL = 'wss://broker.hivemq.com:8884/mqtt';
// FOR ACTUAL PRIVATE BROKER
const MQTT_BROKER_URL = 'wss://fe26426fbe64463790fc2792777c8189.s1.eu.hivemq.cloud:8884/mqtt';
const MQTT_USER = 'smarthardhat';
const MQTT_PSWD = 'Smarthardhat0';

// TOPICS
// HEARTBEAT TOPIC
const HEARTBEAT_TOPIC = 'igen430/shh/heartbeats/workerA';
// ALERT TOPIC
const ALERTS_TOPIC = 'igen430/shh/alerts/workerA';

const ALL_KEYS = [
    'worker_id',
    'latitude', 'longitude', 
    'fall_detection',
    'aqi_pm25_us', 'aqi_pm100_us', 'aqi_uba', 
    'noise_db',
    'modulesOnline',
  ];

  const ALERT_SCHEMAS = {
    AIR_QUALITY_OVER_THRESHOLD: ['latitude', 'longitude', 'aqi_uba', 'aqi_pm25_us', 'aqi_pm100_us'],
    NOISE_OVER_THRESHOLD: ['latitude', 'longitude', 'noise_db'],
    MANUAL_ALERT: ['latitude', 'longitude', 'fall_detection'],
    MANUAL_CLEAR: ['latitude', 'longitude', 'fall_detection'],
    FALL_IMPACT: ['latitude', 'longitude', 'fall_detection'],
};

// DATA PACKAGE
const DATA_INITIAL_NUMBERS = {
  worker_id: 0,
  event: 0,
  datetime: 0,
  latitude: 0, 
  longitude: 0,
  fall_detection: 0,
  aqi_pm25_us: 0,
  aqi_pm100_us: 0,
  aqi_uba: 0,
  noise_db: 0,
  modulesOnline: [0,0],
  // pm10_env: null, 
  // pm25_env: null, 
  // pm100_env: null,
  // temperature: null,
  // humidity: null,
  // eCO2: null,
  // TVOC: null,
};

export const MqttProvider = ({ children }) => {
    const [data, setData] = useState(DATA_INITIAL_NUMBERS); 
    const [status, setStatus] = useState('connecting');
    const clientRef = useRef(null);
    const activeWorkerRef = useRef(data.worker_id);


    useEffect(() => {
      const INACTIVITY_THRESHOLD = 5 * 60 * 1000; // 5 Minutes
      const CHECK_INTERVAL = 60 * 1000; // Check every 1 minute

      const performHeartbeatCheck = async () => {
          try {
              // 1. Get all unique worker IDs currently in the system
              const workerIds = await db.readings.orderBy('worker_id').uniqueKeys();
              // HARDCODE*****
              // const workerIds = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

              const now = Date.now();

              for (const id of workerIds) {
                // Ignore "alerts" to find the last true "Status" update
                const lastRecord = await db.readings
                  .where('worker_id').equals(id)
                  .filter(record => !record.is_alert) // This ensures partial alerts don't reset the timer
                  .reverse()
                  .first();

                if (lastRecord) {
                    const timeSinceLastSeen = now - lastRecord.timestamp;

                    // 3. If silent for > 5 mins AND last record wasn't already a zero-filler
                    // (Checking lastRecord.noise_db !== 0 avoids spamming zeros if they stay offline)
                    if (timeSinceLastSeen > INACTIVITY_THRESHOLD && !lastRecord.is_inactivity_filler) {
                        const zeroedTimestamp = now;

                        const { id: dbKey, ...recordWithoutId } = lastRecord;
                        
                        const zeroRecord = {
                            ...recordWithoutId,
                            latitude: 0,
                            longitude: 0,
                            timestamp: zeroedTimestamp,
                            datetime: new Date(zeroedTimestamp).toLocaleString(),
                            aqi_pm25_us: 0,
                            aqi_pm100_us: 0,
                            fall_detection: 0,
                            noise_db: 0,
                            aqi_uba: 0,
                            is_inactivity_filler: true,
                            is_alert: false,
                            air_offline: true,
                            noise_offline: true
                        };

                        await db.readings.add(zeroRecord);
                        
                        // 4. If this is the worker currently being viewed, update local state
                        if (activeWorkerRef.current === id) {
                            setData(zeroRecord);
                        }
                        
                        console.log(`Worker ${id} timed out. Zero-values injected.`);
                    }
                  }
              }
          } catch (err) {
              console.error("Watchdog Error:", err);
          }
      };

      const interval = setInterval(performHeartbeatCheck, CHECK_INTERVAL);
      return () => clearInterval(interval);
    }, []); // Re-run effect context if the active worker changes

    useEffect(() => {
      activeWorkerRef.current = data.worker_id;
    }, [data.worker_id]);

    const updateData = (newDataObject) => {
      setData(prevData => ({
          ...prevData,
          ...newDataObject
      }));
  };

    // Convert JSON string values to numbers
    const parseJsonToNumbers = (data, keys) => {
      const parsedData = {};
      for (const key of keys) {
          const val = data[key];
          // If it's an array, keep it as is. Otherwise, try to parse it.
          if (Array.isArray(val)) {
              parsedData[key] = val;
          } else {
              parsedData[key] = isNaN(parseFloat(val)) ? 0 : parseFloat(val);
          }
      }
      return parsedData;
    };

    // Helper function: Converts "2026/01/19,10:30:45" to a valid Unix Timestamp (ms)
  const parseDeviceTime = (datetimeStr) => {
    if (!datetimeStr) return null;
    const [datePart, timePart] = datetimeStr.split(',');
    if (!datePart || !timePart) return null;
    
    // Append 'Z' to the end to force UTC interpretation
    // "2026-03-19T00:53:50Z"
    const isoString = `${datePart.replace(/\//g, '-')}T${timePart}Z`;
    const timestamp = new Date(isoString).getTime();
    
    return isNaN(timestamp) ? null : timestamp;
};

    useEffect(() => {
      // FOR ACTUAL PRIVATE BROKER
      const options = {
          username: MQTT_USER,
          password: MQTT_PSWD,
          clientId: `web_client_${Math.random().toString(16).slice(2, 8)}`, // Unique ID to prevent connection drops
          clean: true,
          connectTimeout: 4000,
          reconnectPeriod: 1000,
      };

        // 1. Initialize MQTT Client
        const client = mqtt.connect(MQTT_BROKER_URL, options); 
        clientRef.current = client; 

        // 2. Event handlers
        client.on('connect', () => {
            console.log('MQTT Connected!');
            setStatus('connected');
            // 3. Subscribe to the topics
            client.subscribe([HEARTBEAT_TOPIC, ALERTS_TOPIC], (err) => {
              if (!err) {
                  console.log(`Subscribed to: ${HEARTBEAT_TOPIC} and ${ALERTS_TOPIC}`);
              } else {
                  console.error('Subscription error:', err);
              }
          });
        });

        client.on('message', async (topic, message) => {
          // Already converted in ESP32 - but just in case convert to string
          const payload = message.toString();

          console.log(`Received Data on ${topic}: ${payload}`);

          try {
            const rawData = JSON.parse(payload);
            // Extract and parse the device's sent time - // "2026/01/19,10:30:45"
            const deviceTimeStr = rawData['datetime'];
            // Attempt to parse "Time Sent", fallback to Date.now() if it fails
            const sentTimestamp = parseDeviceTime(deviceTimeStr) || Date.now();
            const worker_id = parseInt(rawData.worker_id) || 0;
    
            let dataToSave = {};
            let isAlert = false;
    
            // Logic Switch based on Topic
            if (topic === HEARTBEAT_TOPIC) {
              // 1. Initial parse of all keys
              dataToSave = parseJsonToNumbers(rawData, ALL_KEYS); 
              
              const modules = dataToSave.modulesOnline || [0, 0];
              const airOffline = modules[0] !== 3;
              const noiseOffline = modules[1] !== 2;

              if (airOffline) {
                  dataToSave.aqi_uba = 0;
                  dataToSave.aqi_pm25_us = 0;
                  dataToSave.aqi_pm100_us = 0;
              }
              
              if (noiseOffline) {
                  dataToSave.noise_db = 0;
              }

              // Attach flags to dataToSave
              dataToSave.air_offline = airOffline;
              dataToSave.noise_offline = noiseOffline;

            } 
            else if (topic === ALERTS_TOPIC) {
                const eventType = rawData.event;
                const schema = ALERT_SCHEMAS[eventType];
    
                if (schema) {
                    // Only parse the keys relevant to this specific event type
                    dataToSave = parseJsonToNumbers(rawData, schema);
                    console.log(`Processing Alert: ${eventType}`);
                    isAlert = true;
                    
                } else {
                    console.warn(`Received unknown event type: ${eventType}`);
                    return; // Exit if the event type isn't recognized
                }
            }

            // Validate that we actually have data to process
            const hasValidData = Object.keys(dataToSave).length > 0;

            if (hasValidData) {
              // Add metadata required for DB and State
              const finalRecord = {
                  ...dataToSave,
                  worker_id, // Ensure worker_id is always present for indexing
                  timestamp: sentTimestamp,
                  datetime: (deviceTimeStr && !isNaN(parseDeviceTime(deviceTimeStr))) 
                    ? deviceTimeStr 
                    : new Date(sentTimestamp).toLocaleString(),
                  event: rawData.event || 'HEARTBEAT',
                  is_alert: isAlert,
                  air_offline: dataToSave.air_offline || false,
                  noise_offline: dataToSave.noise_offline || false,
              };
    
              try {
                  await db.readings.add(finalRecord);
                  console.log(`Data saved. Source: ${deviceTimeStr ? 'Device' : 'System Fallback'}`);
              } catch (error) {
                  console.error(`Failed to save to DB: ${error}`);
              }
            if (worker_id === activeWorkerRef.current) {
              updateData(finalRecord);
          }

            }
        } catch (e) {
            console.error(`Error processing message on ${topic}:`, e);
            console.log(`Error: Bad JSON payload received: ${payload}`);
        }
    });

    client.on('error', (err) => {
      console.error('MQTT Connection Error:', err);
      setStatus('error');
    });

    // 3. Cleanup function: Runs when the component unmounts
    return () => {
      if (clientRef.current) {
        clientRef.current.end(true, () => {
          console.log('MQTT Disconnected');
        });
      }
    };
  }, []); // Run effect only once on mount

  return (
    <MqttContext.Provider value={{ data, status }}>
        {children}
    </MqttContext.Provider>
  );
}

export const useMqtt = () => useContext(MqttContext);