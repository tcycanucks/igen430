import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, ZoomControl, Marker, Popup } from 'react-leaflet';
import { MAP_LOCATIONS } from './Data.js';
import { db } from './db';
import L from 'leaflet';
import './Homepage.css';
import 'leaflet/dist/leaflet.css';
import { calculateNoiseMetrics } from './noiseUtils';

const REFRESH_TIME = 1000; // 1 second

const HomepageMap = ({ center, zoom, workerLocations, activeAirAlerts, activeNoiseAlerts, setSelectedWorkerId }) => {
  const createCustomIcon = (worker) => {
    // Treat fall_detection 1 (Auto) and 2 (SOS) as high-priority red alerts
    const isFall = worker.fall_detection === 1 || worker.fall_detection === 2;
    const isAirWarning = activeAirAlerts.some(alert => alert.worker_id === worker.worker_id);
    const isNoiseWarning = activeNoiseAlerts.some(alert => alert.worker_id === worker.worker_id);
    
    let color = '#3b82f6'; // blue
    let animationClass = '';

    if (isFall) {
      color = '#ef4444'; // Red
      animationClass = 'marker-pulse-red';
    } else if (isAirWarning || isNoiseWarning) { 
      color = '#f97316'; // Orange 
      animationClass = 'marker-pulse-orange';
    }

    return L.divIcon({
      className: `custom-marker-wrapper ${animationClass}`,
      // Standardized Pin Path for reliability
      html: `
        <div class="marker-pin" style="background-color: ${color};">
          <div class="marker-dot"></div>
        </div>`,
      iconSize: [30, 30],
      iconAnchor: [15, 30],
      popupAnchor: [0, -30]
    });
  };

  return (
    <div className="map-container-wrapper">
      <MapContainer 
        center={center || [0, 0]}
        zoom={zoom || 13}
        scrollWheelZoom={true}
        dragging={true}
        doubleClickZoom={true}
        touchZoom={true}
        keyboard={true}
        zoomControl={false}
        className="leaflet-map-container"
        key={center ? center.toString() : 'default-map'}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <ZoomControl position="bottomright" />
        
        {workerLocations.map((worker) => (
          <Marker 
            key={worker.worker_id} 
            position={[worker.latitude, worker.longitude]}
            icon={createCustomIcon(worker)} 
            eventHandlers={{
              click: () => setSelectedWorkerId(worker.worker_id),
              popupclose: () => setSelectedWorkerId(null),
            }}
          >
            <Popup>
              <strong>Worker ID: {worker.worker_id}</strong><br />
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};


const WarningCard = ({ type, title, workerId, location, rating, recommendations, onClick, onDismiss }) => {
  const [showOptions, setShowOptions] = React.useState(false);
  
  const headerColor = type === 'fall' ? '#ef4444' : '#f97316'; 

  // Use fallbacks for coordinates to prevent .toFixed() crash
  const lat = location?.[0] ?? 0;
  const lng = location?.[1] ?? 0;
  
  return (
    <div className={`warning-card ${type}`}>
      {/* X Dismiss Button */}
      <button 
        className="dismiss-trigger"
        onClick={(e) => { 
          e.stopPropagation(); 
          setShowOptions(!showOptions); 
        }}
      >
        ✕
      </button>

      {/* Floating Action Menu */}
      {showOptions && (
        <div className="dismiss-popup-menu">
          <div className="menu-header">Mute for:</div>
          <button onClick={(e) => { e.stopPropagation(); onDismiss(workerId, type, 15); setShowOptions(false); }}>
            15 Min
          </button>
          <button onClick={(e) => { e.stopPropagation(); onDismiss(workerId, type, null); setShowOptions(false); }}>
            Today
          </button>
          <button className="menu-cancel" onClick={(e) => { e.stopPropagation(); setShowOptions(false); }}>
            Cancel
          </button>
        </div>
      )}

      <div className="card-inner-content" onClick={() => onClick(lat, lng)} style={{ cursor: 'pointer' }}>
        <div className="card-icon-container" style={{ backgroundColor: headerColor }}>
          {/* SVG Alert Icon */}
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M15.459 0.344182C15.6329 0.144199 15.8791 0.0214406 16.1435 0.00287747C16.4079 -0.0156856 16.6688 0.0714649 16.869 0.245181C18.1622 1.36786 19.2013 2.75331 19.917 4.30918C20.0279 4.55026 20.0384 4.82551 19.9463 5.07437C19.8542 5.32323 19.6671 5.52532 19.426 5.63618C19.1849 5.74704 18.9097 5.75759 18.6608 5.66551C18.4119 5.57343 18.2099 5.38626 18.099 5.14518C17.5028 3.84756 16.6369 2.69189 15.559 1.75518C15.3589 1.58139 15.2359 1.33527 15.2172 1.07088C15.1984 0.80649 15.2854 0.544473 15.459 0.344182Z" fill="white"/>
  <path d="M3.14399 0.245182C3.34423 0.0712003 3.60538 -0.0161113 3.86999 0.00245484C4.1346 0.0210209 4.381 0.143944 4.55499 0.344183C4.72897 0.544421 4.81628 0.805572 4.79771 1.07019C4.77915 1.3348 4.65623 1.5812 4.45599 1.75518C3.37809 2.69189 2.51219 3.84756 1.91599 5.14518C1.86269 5.26685 1.7857 5.37669 1.68949 5.46827C1.59328 5.55986 1.47979 5.63136 1.35564 5.6786C1.23149 5.72584 1.09918 5.74787 0.966422 5.74341C0.833666 5.73895 0.703129 5.70809 0.582433 5.65262C0.461737 5.59716 0.3533 5.5182 0.263455 5.42036C0.17361 5.32253 0.104156 5.20777 0.0591501 5.0828C0.0141439 4.95782 -0.00551315 4.82514 0.00132669 4.69248C0.00816653 4.55983 0.0413662 4.42986 0.0989872 4.31018C0.813654 2.75423 1.85171 1.36846 3.14399 0.245182Z" fill="white"/>
  <path d="M12.243 17.0002C13.108 17.0002 13.565 18.0242 12.988 18.6682C12.6132 19.0876 12.1539 19.4231 11.6404 19.6527C11.1268 19.8822 10.5706 20.0007 10.008 20.0002C9.4455 20.0007 8.88922 19.8822 8.37566 19.6527C7.8621 19.4231 7.40285 19.0876 7.02802 18.6682C6.47602 18.0522 6.87002 17.0892 7.66202 17.0072L7.77202 17.0012L12.243 17.0002Z" fill="white"/>
  <path d="M10.008 0.000183106C11.366 0.000183106 12.514 0.903183 12.883 2.14118L12.929 2.31218L12.937 2.35518C14.0394 2.97708 14.9788 3.85129 15.6782 4.90618C16.3777 5.96108 16.8173 7.16666 16.961 8.42418L16.989 8.71118L17.008 9.00018V11.9312L17.029 12.0672C17.1659 12.804 17.5737 13.4629 18.172 13.9142L18.339 14.0312L18.501 14.1302C19.361 14.6172 19.061 15.8962 18.124 15.9942L18.008 16.0002H2.008C0.980004 16.0002 0.621004 14.6362 1.515 14.1302C1.89603 13.9146 2.22525 13.6181 2.47954 13.2618C2.73384 12.9054 2.90704 12.4976 2.987 12.0672L3.008 11.9242L3.009 8.95418C3.06998 7.64806 3.45016 6.37679 4.11629 5.25165C4.78241 4.12651 5.71417 3.18179 6.83 2.50018L7.078 2.35418L7.088 2.31118C7.22946 1.71321 7.55095 1.17302 8.00909 0.76352C8.46723 0.354019 9.03997 0.0949177 9.65 0.021183L9.832 0.00418305L10.008 0.000183106Z" fill="white"/>
  <path d="M15.459 0.344182C15.6329 0.144199 15.8791 0.0214406 16.1435 0.00287747C16.4079 -0.0156856 16.6688 0.0714649 16.869 0.245181C18.1622 1.36786 19.2013 2.75331 19.917 4.30918C20.0279 4.55026 20.0384 4.82551 19.9463 5.07437C19.8542 5.32323 19.6671 5.52532 19.426 5.63618C19.1849 5.74704 18.9097 5.75759 18.6608 5.66551C18.4119 5.57343 18.2099 5.38626 18.099 5.14518C17.5028 3.84756 16.6369 2.69189 15.559 1.75518C15.3589 1.58139 15.2359 1.33527 15.2172 1.07088C15.1984 0.80649 15.2854 0.544473 15.459 0.344182Z" stroke="white"/>
  <path d="M3.14399 0.245182C3.34423 0.0712003 3.60538 -0.0161113 3.86999 0.00245484C4.1346 0.0210209 4.381 0.143944 4.55499 0.344183C4.72897 0.544421 4.81628 0.805572 4.79771 1.07019C4.77915 1.3348 4.65623 1.5812 4.45599 1.75518C3.37809 2.69189 2.51219 3.84756 1.91599 5.14518C1.86269 5.26685 1.7857 5.37669 1.68949 5.46827C1.59328 5.55986 1.47979 5.63136 1.35564 5.6786C1.23149 5.72584 1.09918 5.74787 0.966422 5.74341C0.833666 5.73895 0.703129 5.70809 0.582433 5.65262C0.461737 5.59716 0.3533 5.5182 0.263455 5.42036C0.17361 5.32253 0.104156 5.20777 0.0591501 5.0828C0.0141439 4.95782 -0.00551315 4.82514 0.00132669 4.69248C0.00816653 4.55983 0.0413662 4.42986 0.0989872 4.31018C0.813654 2.75423 1.85171 1.36846 3.14399 0.245182Z" stroke="white"/>
  <path d="M12.243 17.0002C13.108 17.0002 13.565 18.0242 12.988 18.6682C12.6132 19.0876 12.1539 19.4231 11.6404 19.6527C11.1268 19.8822 10.5706 20.0007 10.008 20.0002C9.4455 20.0007 8.88922 19.8822 8.37566 19.6527C7.8621 19.4231 7.40285 19.0876 7.02802 18.6682C6.47602 18.0522 6.87002 17.0892 7.66202 17.0072L7.77202 17.0012L12.243 17.0002Z" stroke="white"/>
  <path d="M10.008 0.000183106C11.366 0.000183106 12.514 0.903183 12.883 2.14118L12.929 2.31218L12.937 2.35518C14.0394 2.97708 14.9788 3.85129 15.6782 4.90618C16.3777 5.96108 16.8173 7.16666 16.961 8.42418L16.989 8.71118L17.008 9.00018V11.9312L17.029 12.0672C17.1659 12.804 17.5737 13.4629 18.172 13.9142L18.339 14.0312L18.501 14.1302C19.361 14.6172 19.061 15.8962 18.124 15.9942L18.008 16.0002H2.008C0.980004 16.0002 0.621004 14.6362 1.515 14.1302C1.89603 13.9146 2.22525 13.6181 2.47954 13.2618C2.73384 12.9054 2.90704 12.4976 2.987 12.0672L3.008 11.9242L3.009 8.95418C3.06998 7.64806 3.45016 6.37679 4.11629 5.25165C4.78241 4.12651 5.71417 3.18179 6.83 2.50018L7.078 2.35418L7.088 2.31118C7.22946 1.71321 7.55095 1.17302 8.00909 0.76352C8.46723 0.354019 9.03997 0.0949177 9.65 0.021183L9.832 0.00418305L10.008 0.000183106Z" stroke="white"/>
          </svg>

        </div>
        <div className="card-content">
          <p className="card-title">{title}</p>
          <div className="card-details">
            <strong>Worker ID:</strong> {workerId} | <strong>GPS:</strong> {lat.toFixed(4)}, {lng.toFixed(4)}
            {rating && <><br /><strong>Air Quality Rating:</strong> {rating}</>}
            {recommendations && (
              <div className="epa-recommendations" style={{ marginTop: '8px' }}>
                {recommendations.split(' — ').map((rec, index) => (
                  <div key={index} style={{ marginBottom: '4px' }}>
                    {rec}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

    </div>


    
  );
};

const ClearDropdown = ({ label, onSelect, isDanger, disabled }) => {
  const [isOpen, setIsOpen] = useState(false);

  // If disabled, we return a greyed out version to keep the UI spacing consistent
  if (disabled) {
    return (
      <div className="clear-dropdown-wrapper">
      <button 
        className={`btn-clear-main ${isDanger ? 'danger' : ''}`}
        onClick={() => setIsOpen(!isOpen)}
      >
        {label} ▾
      </button>
      {isOpen && (
        <div className="clear-all-popup">
          <button onClick={() => { onSelect(15); setIsOpen(false); }}>Mute 15m</button>
          <button onClick={() => { onSelect(null); setIsOpen(false); }}>Mute Today</button>
          <button className="menu-cancel" onClick={() => setIsOpen(false)}>Cancel</button>
        </div>
      )}
    </div>
    );
  }
  
  return (
    <div className="clear-dropdown-wrapper">
      <button 
        className={`btn-clear-main ${isDanger ? 'danger' : ''}`}
        onClick={() => setIsOpen(!isOpen)}
      >
        {label} ▾
      </button>
      {isOpen && (
        <div className="clear-all-popup">
          <button onClick={() => { onSelect(15); setIsOpen(false); }}>Mute 15m</button>
          <button onClick={() => { onSelect(null); setIsOpen(false); }}>Mute Today</button>
          <button className="menu-cancel" onClick={() => setIsOpen(false)}>Cancel</button>
        </div>
      )}
    </div>
  );
};

const Homepage = () => {
  const initialLocationKey = Object.keys(MAP_LOCATIONS)[0]; 
  
  // const [mapView, setMapView] = useState(MAP_LOCATIONS[initialLocationKey]);

  const [workerLocations, setWorkerLocations] = useState([]);
  const [selectedWorkerId, setSelectedWorkerId] = useState(null);
  const [activeFallAlerts, setActiveFallAlerts] = useState([]);
  const [activeAirAlerts, setActiveAirAlerts] = useState([]);
  const [activeNoiseAlerts, setActiveNoiseAlerts] = useState([]);
  const [visibleTypes, setVisibleTypes] = useState(['fall', 'air', 'noise']);

  const locationKeys = Object.keys(MAP_LOCATIONS || {});
  const initialKey = locationKeys.length > 0 ? locationKeys[0] : null;

  const [mapView, setMapView] = useState(
    initialKey ? MAP_LOCATIONS[initialKey] : { coords: [0, 0], zoom: 2 }
  );

  const clearFilters = () => {
    setVisibleTypes([]);
  };

  const toggleFilter = (type) => {
    setVisibleTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  // ALERTS
  const activeFalls = workerLocations.filter(worker => worker.fall_detection === 1);

  const getAirQualityInfo = (pmValue, ubaValue) => {
    let pmInfo = null;
    let ubaInfo = null;
  
    // German UBA Standard Logic
    if (ubaValue >= 5) {
      ubaInfo = { label: "Level 5: Very Poor (UBA)", rec: "UBA: Severe health risk. Minimize outdoor activities; vulnerable individuals should stay indoors." };
    } else if (ubaValue >= 4) {
      ubaInfo = { label: "Level 4: Poor (UBA)", rec: "UBA: Significant health concern. Air is polluted; avoid prolonged outdoor exposure." };
    }
  
    // US EPA PM2.5/PM10 Standard Logic
    if (pmValue >= 300) {
      pmInfo = { label: "Hazardous (Particulate Matter Index)", 
        rec: "US EPA: Everyone: Avoid all physical activity outdoors. Sensitive groups: Remain indoors and keep activity levels low." };
    } else if (pmValue >= 200) {
      pmInfo = { label: "Very Unhealthy (Particulate Matter Index)", 
        rec: "US EPA: Sensitive groups: Avoid all physical activity outdoors. Everyone else: Avoid prolonged or heavy exertion." };
    } else if (pmValue >= 150) {
      pmInfo = { label: "Unhealthy (Particulate Matter Index)", 
        rec: "US EPA: Sensitive groups: Avoid prolonged or heavy exertion. Everyone else: Reduce prolonged or heavy exertion." };
    }
  
    return { pmInfo, ubaInfo };
  };

  // TRACKING MUTED ALERTS
  // 1. Add state to track muted alerts
  // Format: { 'workerID-type': expiryTimestamp }
  const [mutedAlerts, setMutedAlerts] = useState({});

  // 2. Helper to mute an alert
  const handleDismiss = (workerId, type, durationMinutes) => {
    const expiry = durationMinutes 
      ? Date.now() + durationMinutes * 60 * 1000 
      : new Date().setHours(23, 59, 59, 999); // End of day

    setMutedAlerts(prev => ({
      ...prev,
      [`${workerId}-${type}`]: expiry
    }));
  };

  // 3. global action logic
  const handleBulkMute = (category, durationMinutes) => {
    const expiry = durationMinutes 
      ? Date.now() + durationMinutes * 60 * 1000 
      : new Date().setHours(23, 59, 59, 999);
  
    const massMute = {};
    
    // Helper to add alerts to the mute list
    const addToMuteList = (alerts, type) => {
      alerts.forEach(a => {
        massMute[`${a.worker_id}-${type}`] = expiry;
      });
    };
  
    if (category === 'all' || category === 'fall') addToMuteList(activeFallAlerts, 'fall');
    if (category === 'all' || category === 'air') addToMuteList(activeAirAlerts, 'air');
    if (category === 'all' || category === 'noise') addToMuteList(activeNoiseAlerts, 'noise');
  
    setMutedAlerts(prev => ({ ...prev, ...massMute }));
  };


  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  
        // 1. Get all readings from today only
        const allReadings = await db.readings
          .where('timestamp')
          .aboveOrEqual(startOfToday)
          .reverse()
          .toArray();
  
        // 2. Group all readings by worker ID to access history
        const workerGroups = {};
        allReadings.forEach((r) => {
          if (!workerGroups[r.worker_id]) workerGroups[r.worker_id] = [];
          workerGroups[r.worker_id].push(r);
        });
  
        // Temporary arrays to collect ALL workers' data before setting state
        const airWarnings = [];
        const fallWarnings = [];
        const noiseWarnings = [];
        const markersForMap = [];
  
        // 3. Process each worker's history
        Object.keys(workerGroups).forEach((id) => {
          const history = workerGroups[id];
          const latest = history[0];
          // If the worker is offline/inactive, skip markers AND all alert logic
          if (!latest || latest.is_inactivity_filler || latest.latitude === 0) return;

          // 1. Add to map markers (since they passed the guard above, they are active)
          markersForMap.push(latest);
  
          // FALL DETECTION LOGIC (Latest only)
          if (latest.fall_detection === 1 || latest.fall_detection === 2) {
            fallWarnings.push({
              ...latest,
              displayTitle: latest.fall_detection === 2 
                ? "Worker SOS - please follow-up!" 
                : "Potential fall detected!"
            });
          }

          // AIR QUALITY LOGIC (Average of latest 5)
          const last3 = history.slice(0, 3);
          if (last3.length >= 3) {
            // 1. Calculate Averages based on the last 3 records
            const avgPM25 = last3.reduce((sum, r) => sum + (r.aqi_pm25_us || 0), 0) / last3.length;
            const avgPM100 = last3.reduce((sum, r) => sum + (r.aqi_pm100_us || 0), 0) / last3.length;
            const avgUBA = last3.reduce((sum, r) => sum + (r.aqi_uba || 0), 0) / last3.length;
        
            const maxAvgPM = Math.max(avgPM25, avgPM100);
        
            const { pmInfo, ubaInfo } = getAirQualityInfo(maxAvgPM, avgUBA);
        
            const isPMTrigger = maxAvgPM >= 150;
            const isUBATrigger = avgUBA >= 4;
        
            if (isPMTrigger || isUBATrigger) {
                let ratings = [];
                let recs = [];
                let sources = [];
            
                // Check UBA Trigger
                if (isUBATrigger && ubaInfo) {
                    ratings.push(ubaInfo.label);
                    recs.push(ubaInfo.rec);
                    sources.push("UBA");
                }
            
                // Check PM Trigger
                if (isPMTrigger && pmInfo) {
                    ratings.push(pmInfo.label);
                    recs.push(pmInfo.rec);
                    sources.push("PM");
                }
            
                airWarnings.push({ 
                    ...latest, 
                    displayTitle: `Poor air quality alert (${sources.join(" & ")})`,
                    rating: ratings.join(" | "), 
                    recommendations: recs.join(" — "), 
                    avgPM: maxAvgPM.toFixed(1),
                    avgUBA: avgUBA.toFixed(1)
                });
            }
          }
    

          // NOISE LOGIC 
          // Trigger if:
            // 1. Instant noise is >= 120 (Immediate danger)
            // 2. Actual dose exceeded
            // 3. Projected dose exceeded

            // ENHANCED NOISE LOGIC using shared utility
            const noiseMetrics = calculateNoiseMetrics(history);
            let noiseAlert = null;

            // Extract values safely from the 'metrics' object
            const currentDose = Number(noiseMetrics?.dose || 0);
            const projectedDose = Number(noiseMetrics?.projectedDose || 0);
            const latestDb = Number(noiseMetrics?.latest || 0);

            // 1. Immediate Danger (Instant Peak)
            if (latestDb >= 120) {
              noiseAlert = { 
                ...latest, 
                noiseReason: "IMMEDIATE DANGER: Instant noise level ≥ 120dB detected." 
              };
            } 
            // 2. Critical Warning (Actual Dose hit 100%)
            else if (currentDose >= 100) {
              noiseAlert = { 
                ...latest, 
                noiseReason: `CRITICAL: Daily noise dose limit reached (${currentDose.toFixed(0)}%).` 
              };
            } 
            // 3. Caution (Projected to hit 100%)
            else if (projectedDose >= 100) {
              noiseAlert = { 
                ...latest, 
                noiseReason: `CAUTION: Projected to exceed daily noise limit (${projectedDose.toFixed(0)}%).` 
              };
            }

            if (noiseAlert) {
              noiseWarnings.push(noiseAlert);
            }

            const nowTs = Date.now();

            // Clean up expired mutes first
            const activeMutes = Object.fromEntries(
              Object.entries(mutedAlerts).filter(([_, expiry]) => expiry > nowTs)
            );

            // Filter the warnings
            const finalFalls = fallWarnings.filter(w => !activeMutes[`${w.worker_id}-fall`]);
            const finalAir = airWarnings.filter(w => !activeMutes[`${w.worker_id}-air`]);
            const finalNoise = noiseWarnings.filter(w => !activeMutes[`${w.worker_id}-noise`]);

            setWorkerLocations(markersForMap);
            setActiveFallAlerts(finalFalls); 
            setActiveAirAlerts(finalAir);
            setActiveNoiseAlerts(finalNoise);
        });
  
      } catch (error) {
        console.error("Error fetching worker locations:", error);
      }
    };
  
    fetchLocations();
    const interval = setInterval(fetchLocations, REFRESH_TIME);
    return () => clearInterval(interval);
  }, [mutedAlerts]);


  // LOCATION CHANGE BASED ON CHOICE
  const handleLocationChange = (event) => {
    const selectedLocation = event.target.value;
    if (MAP_LOCATIONS[selectedLocation]) {
      setMapView(MAP_LOCATIONS[selectedLocation]);
    }
  };

  const handleWarningClick = (lat, lng) => {
    setMapView({
      coords: [lat, lng],
      zoom: 18 // Zoom in close to the worker
    });
  };

  // LOGIC TO FILTER BASED ON SELECTED WORKER ID
  const filteredFall = selectedWorkerId 
    ? activeFallAlerts.filter(a => a.worker_id === selectedWorkerId) 
    : activeFallAlerts;

  const filteredAir = selectedWorkerId 
    ? activeAirAlerts.filter(a => a.worker_id === selectedWorkerId) 
    : activeAirAlerts;

  const filteredNoise = selectedWorkerId 
    ? activeNoiseAlerts.filter(a => a.worker_id === selectedWorkerId) 
    : activeNoiseAlerts;

  return (
    <>
      <h1>Homepage</h1>
    

      <div className="homepage-main-layout">
        <div className="main-content-left">
          <div className="location-select-container">
            <select 
              id="location-select" 
              className="custom-select" 
              onChange={handleLocationChange} 
              defaultValue="Select Location"
            >
              {Object.keys(MAP_LOCATIONS).map((key) => (
                <option key={key} value={key}>{key}</option>
              ))}
            </select>
          </div>
    
          <div className="map-section">
            <HomepageMap 
              center={mapView.coords} 
              zoom={mapView.zoom} 
              workerLocations={workerLocations}
              activeAirAlerts={activeAirAlerts}
              activeNoiseAlerts={activeNoiseAlerts}
              setSelectedWorkerId={setSelectedWorkerId}
            />
          </div>
        </div>  

        {/* Active Warnings Sidebar */}
        <div className="active-warnings-sidebar">
          <div className="global-actions">
            <h3 style={{ margin: 0 }}>Active Warnings</h3>
            
            {/* Global Clear All */}
            <ClearDropdown 
              label="Clear All" 
              onSelect={(mins) => handleBulkMute('all', mins)} 
              isDanger 
            />
          </div>
            <div className="filter-bar">
              {/* Category Filters with embedded Clear options */}
              {[
                { id: 'fall', label: 'Falls', count: activeFallAlerts.length, color: '#FEF9C3', 
                  icon: <svg width="22" height="25" viewBox="0 0 22 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M9 24L10.3333 17.2353L9 11.8235L5 6.41176M5 6.41176H10.3333L14.3333 2.35294M5 6.41176L1 11.8235L2.33333 17.2353M12.3333 11.8235H15.6667L21 14.5294M1 2.35294C1 2.71176 1.14048 3.05589 1.39052 3.30961C1.64057 3.56334 1.97971 3.70588 2.33333 3.70588C2.68696 3.70588 3.02609 3.56334 3.27614 3.30961C3.52619 3.05589 3.66667 2.71176 3.66667 2.35294C3.66667 1.99412 3.52619 1.64999 3.27614 1.39627C3.02609 1.14254 2.68696 1 2.33333 1C1.97971 1 1.64057 1.14254 1.39052 1.39627C1.14048 1.64999 1 1.99412 1 2.35294Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                },
                { id: 'air', label: 'Air Quality', count: activeAirAlerts.length, color: '#DBEAFE',
                  icon: <svg width="22" height="21" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M6.55556 14.9333C6.55556 15.9412 6.20437 16.9077 5.57924 17.6203C4.95412 18.333 4.10628 18.7333 3.22222 18.7333M15.4444 14.9333C15.4444 15.9412 15.7956 16.9077 16.4208 17.6203C17.0459 18.333 17.8937 18.7333 18.7778 18.7333M11 14.9333V20M5.44444 11.1333V7.33333C5.44444 6.99739 5.56151 6.67521 5.76988 6.43766C5.97826 6.20012 6.26087 6.06667 6.55556 6.06667H15.4444C15.7391 6.06667 16.0217 6.20012 16.2301 6.43766C16.4385 6.67521 16.5556 6.99739 16.5556 7.33333V11.1333M1 3.53333C1 2.86145 1.23413 2.21709 1.65087 1.742C2.06762 1.2669 2.63285 1 3.22222 1H18.7778C19.3671 1 19.9324 1.2669 20.3491 1.742C20.7659 2.21709 21 2.86145 21 3.53333V8.6C21 9.27188 20.7659 9.91624 20.3491 10.3913C19.9324 10.8664 19.3671 11.1333 18.7778 11.1333H3.22222C2.63285 11.1333 2.06762 10.8664 1.65087 10.3913C1.23413 9.91624 1 9.27188 1 8.6V3.53333Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                },
                { id: 'noise', label: 'Noise', count: activeNoiseAlerts.length, color: '#FCE7F3',
                  icon: <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 14.75C1 14.087 1.26339 13.4511 1.73223 12.9822C2.20107 12.5134 2.83696 12.25 3.5 12.25H4.75C5.41304 12.25 6.04893 12.5134 6.51777 12.9822C6.98661 13.4511 7.25 14.087 7.25 14.75V18.5C7.25 19.163 6.98661 19.7989 6.51777 20.2678C6.04893 20.7366 5.41304 21 4.75 21H3.5C2.83696 21 2.20107 20.7366 1.73223 20.2678C1.26339 19.7989 1 19.163 1 18.5V14.75ZM1 14.75V11C1 8.34784 2.05357 5.8043 3.92893 3.92893C5.8043 2.05357 8.34784 1 11 1C13.6522 1 16.1957 2.05357 18.0711 3.92893C19.9464 5.8043 21 8.34784 21 11V14.75M21 14.75C21 14.087 20.7366 13.4511 20.2678 12.9822C19.7989 12.5134 19.163 12.25 18.5 12.25H17.25C16.587 12.25 15.9511 12.5134 15.4822 12.9822C15.0134 13.4511 14.75 14.087 14.75 14.75V18.5C14.75 19.163 15.0134 19.7989 15.4822 20.2678C15.9511 20.7366 16.587 21 17.25 21H18.5C19.163 21 19.7989 20.7366 20.2678 20.2678C20.7366 19.7989 21 19.163 21 18.5V14.75Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                }
              ].map(item => (
                <div key={item.id} style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '110px' }}>
                  <label className={`filter-chip ${visibleTypes.includes(item.id) ? `active ${item.id}` : ''}`}>
                    <input 
                      type="checkbox" 
                      checked={visibleTypes.includes(item.id)} 
                      onChange={() => toggleFilter(item.id)}
                      style={{ display: 'none' }} 
                    />
                    <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      {item.icon} {item.label} ({item.count})
                    </span>
                  </label>
                  
                  {/* Add the specific category clear button here */}
                  <ClearDropdown 
                    label={`Clear ${item.id.charAt(0).toUpperCase() + item.id.slice(1)}`} 
                    onSelect={(mins) => handleBulkMute(item.id, mins)} 
                    disabled={item.count === 0} 
                  />
                </div>
              ))}

              {visibleTypes.length > 0 && (
                  <button 
                    onClick={clearFilters}
                    className="clear-filters-btn"
                    style={{
                      marginLeft: 'auto',
                      background: 'transparent',
                      border: '1px solid #d1d5db',
                      borderRadius: '16px',
                      padding: '4px 12px',
                      fontSize: '12px',
                      cursor: 'pointer',
                      color: '#4b5563'
                    }}
                  >
                    Clear All Filters
                  </button>
                )}
            </div>

            <hr />

            <div className="sidebar-scroll-content">
              {/* Update Fall Alerts Mapping */}
              {visibleTypes.includes('fall') && filteredFall.map(w => (
                <WarningCard 
                  key={`fall-${w.worker_id}`}
                  type="fall"
                  title={w.displayTitle}
                  workerId={w.worker_id}
                  location={[w.latitude, w.longitude]}
                  onClick={handleWarningClick}
                  onDismiss={handleDismiss}
                />
              ))}

              {/* Update Air Alerts Mapping */}
              {visibleTypes.includes('air') && filteredAir.map(w => (
                <WarningCard 
                  key={`air-${w.worker_id}`}
                  type="air"
                  title={w.displayTitle} 
                  workerId={w.worker_id}
                  location={[w.latitude, w.longitude]}
                  rating={`${w.rating} (3-cycle avg)`}
                  recommendations={w.recommendations}
                  onClick={handleWarningClick}
                  onDismiss={handleDismiss}
                />
              ))}

              {/* Update Noise Alerts Mapping */}
              {visibleTypes.includes('noise') && filteredNoise.map(w => (
                <WarningCard 
                  key={`noise-${w.worker_id}`}
                  type="noise" 
                  title={w.noiseReason}
                  workerId={w.worker_id}
                  location={[w.latitude, w.longitude]}
                  onClick={handleWarningClick}
                  onDismiss={handleDismiss}
                />
              ))}


              {/* Empty state check */}
              {visibleTypes.every(t => 
                (t === 'fall' && filteredFall.length === 0) || 
                (t === 'air' && filteredAir.length === 0) || 
                (t === 'noise' && filteredNoise.length === 0)
              ) && <p className="empty-state">No warnings found for selected filters.</p>}
            </div>
        </div>
      </div>
    </>
  );
};

export default Homepage;
