# Summary

Date : 2026-03-20 17:35:13

Directory /Users/rachael/Documents/IGEN 430/smart-hard-hat/smart hard hat igen 430

Total : 19 files,  6853 codes, 258 comments, 486 blanks, all 7597 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 2 | 3,885 | 0 | 2 | 3,887 |
| JavaScript JSX | 5 | 1,995 | 195 | 295 | 2,485 |
| CSS | 3 | 828 | 42 | 150 | 1,020 |
| JavaScript | 5 | 115 | 21 | 25 | 161 |
| Markdown | 1 | 15 | 0 | 13 | 28 |
| HTML | 1 | 13 | 0 | 1 | 14 |
| XML | 2 | 2 | 0 | 0 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 19 | 6,853 | 258 | 486 | 7,597 |
| . (Files) | 6 | 3,952 | 1 | 20 | 3,973 |
| public | 1 | 1 | 0 | 0 | 1 |
| src | 12 | 2,900 | 257 | 466 | 3,623 |
| src (Files) | 11 | 2,899 | 257 | 466 | 3,622 |
| src/assets | 1 | 1 | 0 | 0 | 1 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)