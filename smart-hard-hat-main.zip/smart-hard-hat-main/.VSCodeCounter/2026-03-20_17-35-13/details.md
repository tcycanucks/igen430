# Details

Date : 2026-03-20 17:35:13

Directory /Users/rachael/Documents/IGEN 430/smart-hard-hat/smart hard hat igen 430

Total : 19 files,  6853 codes, 258 comments, 486 blanks, all 7597 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 15 | 0 | 13 | 28 |
| [eslint.config.js](/eslint.config.js) | JavaScript | 28 | 0 | 2 | 30 |
| [index.html](/index.html) | HTML | 13 | 0 | 1 | 14 |
| [package-lock.json](/package-lock.json) | JSON | 3,849 | 0 | 1 | 3,850 |
| [package.json](/package.json) | JSON | 36 | 0 | 1 | 37 |
| [public/vite.svg](/public/vite.svg) | XML | 1 | 0 | 0 | 1 |
| [src/0Homepage.jsx](/src/0Homepage.jsx) | JavaScript JSX | 508 | 50 | 92 | 650 |
| [src/2WorkerInfo.jsx](/src/2WorkerInfo.jsx) | JavaScript JSX | 1,162 | 95 | 143 | 1,400 |
| [src/App.css](/src/App.css) | CSS | 79 | 0 | 13 | 92 |
| [src/App.jsx](/src/App.jsx) | JavaScript JSX | 85 | 8 | 9 | 102 |
| [src/Data.js](/src/Data.js) | JavaScript | 22 | 1 | 1 | 24 |
| [src/Homepage.css](/src/Homepage.css) | CSS | 10 | 2 | 2 | 14 |
| [src/MqttContext.jsx](/src/MqttContext.jsx) | JavaScript JSX | 227 | 41 | 49 | 317 |
| [src/assets/react.svg](/src/assets/react.svg) | XML | 1 | 0 | 0 | 1 |
| [src/db.js](/src/db.js) | JavaScript | 5 | 3 | 3 | 11 |
| [src/index.css](/src/index.css) | CSS | 739 | 40 | 135 | 914 |
| [src/main.jsx](/src/main.jsx) | JavaScript JSX | 13 | 1 | 2 | 16 |
| [src/noiseUtils.js](/src/noiseUtils.js) | JavaScript | 49 | 16 | 17 | 82 |
| [vite.config.js](/vite.config.js) | JavaScript | 11 | 1 | 2 | 14 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)