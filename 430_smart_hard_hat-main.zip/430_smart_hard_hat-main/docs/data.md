# Data

# Alert Payload 
This is what is sent to the MQTT broker.

MQTT Topic: `const char* MQTT_TOPIC_ALERTS = "igen430/shh/alerts/workerA";`

| Key | Example | 
|----------|------------|
| `event`  | "NOISE_OVER_THRESHOLD" |
| `datetime` | "2026/01/19,10:30:45" |
| `latitude` | 49.2827 |
| `longitude` | -123.1207 |
| `altitude` | 15 |
| `acc` | 1.22 |
| `gyro` | 2.84 |
| `noise_db` | 120 |

### `event` strings
`"FALL_IMPACT"` <br>
`"NOISE_OVER_THRESHOLD"` <br>
`"AIR_QUALITY_OVER_THRESHOLD"` <br>
`"MANUAL_ALERT"` <br>
`"MANUAL_CLEAR"` <br>

# Heartbeat Payload 
This is what is sent to the MQTT broker.

MQTT Topic: `const char* MQTT_TOPIC_HEARTBEATS = "igen430/shh/heartbeats/workerA";`

| Key | Example | 
|----------|------------|
| `worker_id`  | 10 |
| `modulesOnline` | [`nodeId`, `nodeId`] <br> If this is `[0,0]`, then this means no peripheral modules are 'online'. Air quality module (0x03) and Noise module (0x02) online means `[3,2]`. |
| `latitude` | 49.2827 |
| `longitude` | -123.1207 |
| `altitude` | 15 |
| `hdop` | 0.8  |
| `satellites` | 12 |
| `datetime` | "2026/01/19,10:30:45" |
| `resultant_acc` | 1.22 |
| `resultant_gyro` | 2.84 |
| `aqi_uba` | TBD |
| `aqi_pm100_us` | TBD |
| `aqi_pm25_us` | TBD |
| `noise_db` | 70 |
