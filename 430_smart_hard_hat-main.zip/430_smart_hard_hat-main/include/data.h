#ifndef DATA_H
#define DATA_H

// switch between ESP32 and native build
#ifdef ARDUINO_ARCH_ESP32
  #include <Arduino.h>
  #include <driver/twai.h>
  #include <freertos/queue.h>
  #include "gps_events.h"
#else 
  #include <stdint.h>
  #include <stddef.h>
#endif


extern QueueHandle_t gpsQueue; 

// ======================
// IMU and GPS
// ======================

// GPS data 
struct gpsData {
  double latitude;
  double longitude;
  double altitude; // in meters

  // parameters below are sent as a quality check
  float hdop; // horizontal dilution of precision (lower means better accuracy)
  int satellites; // number of satellites in view ()
  char dateTime[32];

};

struct imuData {
  float accX; // in m/s^2
  float accY;
  float accZ;
  float gyroX; // in rad/s
  float gyroY;
  float gyroZ;
  float resultant_acc;
  float resultant_gyro;
};

// ======================
// CAN Message [11 bits : priority, message type, node] [8 bytes data] 
// ======================

// indicates priority for arbitration
enum CANPriority : uint8_t {
    SAFETY_ALERT    = 0, // threshold exceeded, etc.
    CONTROL   = 1, // gateway commands, acks, etc.
    HEARTBEAT = 2, // anything related to heartbeats 
};

// types of messages that can be sent via CAN bus
enum CANMessageType : uint8_t {
  // HIGHEST PRIORITY 0x0- safety critical 
  // alerting lifecycle has two messages per alert: NOTIFICATION and CLEAR
  ALERT_NOTIFICATION = 0x01, // THRESHOLD EXCEEDED, NEEDS TO BE SENT IMMEDIATELY
  ALERT_ACK = 0x02, // GATEWAY ACKNOLWEDGES IT GOT IT
  ALERT_CLEARED = 0x03, // BACK TO NORMAL
  ALERT_CLEARED_ACK = 0x04, // GATEWAY ACKNOWLEDGES CLEAR 
  /* NOTE: 
   acks required, because need ack specifically from gateway. 
   twai filter still acks so if 2 peripheral modules, don't know which one acked it */

  // MEDIUM PRIORITY 0x2 - heartbeat-related (periodic sensor values, "online" modules)
  HEARTBEAT_REQUEST = 0x05,
  HEARTBEAT_RESPONSE = 0x06,

  // LOW PRIORITY 

};

// indicates which node is sending the message
enum NodeID : uint8_t { 
    GATEWAY_NODE = 0x01,
    NODE_NOISE = 0x02,
    NODE_AIR_Q = 0x03,
};

#define THIS_NODE GATEWAY_NODE
#define MAX_NODES_RECV 2 
#define HEARTBEAT_RESPONSE_TIMEOUT_MS 2000 // wait max 2 seconds for heartbeat response

// types of alerts that can be sent to mqtt publish task 
// (does not incl. periodic tasks like heartbeats)
enum AlertType { 
    FALL_IMPACT, // IMU
    NOISE_OVER_THRESHOLD, 
    AIR_QUALITY_OVER_THRESHOLD, 
    MANUAL_ALERT, // Button Press (PRESS TWICE QUICKLY WITHIN 1-2 SECONDS)
    MANUAL_CLEAR, // Button Press (HOLD FOR 3 SECONDS)
};

// ======================
// MQTT 
// ======================

// structure to package alert data for MQTT
struct AlertPayload {
  AlertType event; // TYPE OF ALERT. this is different than SafetyEvent from analyzeImuData
  char dateTime[32];
  // gps data like lat, long, altitude 
  double latitude;
  double longitude;
  double altitude;
  uint16_t noise_db;
  double fall_detection; // 0 or 1 to indicate fall detected, 2 to indicate SOS 
  uint16_t aqi_uba;
  uint16_t aqi_pm25_us;
  uint16_t aqi_pm100_us;
};


// CAN frame structure for different nodes
typedef struct {
  uint16_t pm25_aqi;
  uint16_t pm100_aqi;
  uint16_t aqi_uba;
  uint16_t reserved; // to make sure 8 bytes in data expected
} __attribute__((packed)) airQualityHB_t;

typedef struct {
  uint8_t seq_num;        // 0-255, wraps around 
  uint8_t alert_mask;      // bit 0 = AQI_UBA, bit 1 = PM2.5, bit 2 = PM10
  uint16_t aqi_uba;        // only valid if alert_mask bit 0 set
  uint16_t pm25_aqi;       // only valid if alert_mask bit 1 set
  uint16_t pm100_aqi;      // only valid if alert_mask bit 2 set
} __attribute__((packed)) airQualityAlert_t;

typedef struct {
  uint16_t noise_db;
  uint16_t reserved[3]; // to make sure 8 bytes in data expected
} __attribute__((packed)) noiseHB_t;

typedef struct {
  uint8_t seq_num;        // 0-255, wraps around 
  uint8_t reserved1; // padding
  uint16_t noise_db;
  uint16_t reserved[2]; // to make sure 8 bytes in data expected
} __attribute__((packed)) noiseAlert_t;


// stuff for heartbeat payload for MQTT - keep everything as low memory as possible (e.g., double rather than float)
struct HeartbeatPayload {
    // array of NodeIDs that responded
    uint8_t modulesOnline[MAX_NODES_RECV] = {0}; // (0 = no module)

    // GPS data
    double latitude;
    double longitude;
    double altitude; // in meters

    // parameters below are sent as a quality check
    float hdop; // horizontal dilution of precision (lower means better accuracy)
    int satellites; // number of satellites in view
    char dateTime[32];
    
    // IMU data 
    float resultant_acc; // resultant acceleration
    float resultant_gyro; // resultant gyroscope

    // air quality data from PM
    // float pm10;
    // float pm25;
    // float pm100;
    uint16_t aqi_pm25_us;
    uint16_t aqi_pm100_us;
    // air quality data from ENS
    // float temperature; 
    // float humidity;
    // float eco2; 
    // float tvoc;
    uint16_t aqi_uba;
    // noise data 
    uint16_t noise_db; // in decibels
};

// tracking structure for collecting heartbeats (need to know state)
struct hbCollection {
    bool isCollecting; 
    TickType_t startTime; 
    HeartbeatPayload payload; // payload.modulesOnline gives array of NodeIDs that responded
};


// helpers related to data structs
const char* alertTypeToString(AlertType type);
bool serializeAP(const AlertPayload& alert, char* buffer, size_t bufferSize);
bool serializeHB(const HeartbeatPayload& heartbeat, char* buffer, size_t bufferSize);
// helpers dealing with heartbeat collection state
bool isCollectionTimedOut(hbCollection& collection);
void aggHeartbeatResponse(NodeID nodeId, const twai_message_t& msg, hbCollection& collection);
void attachGPSToAlert(AlertPayload &alert, EventGroupHandle_t gpsEventGroup, QueueHandle_t gpsQueue);
void attachGPSToHB(HeartbeatPayload &hb, EventGroupHandle_t gpsEventGroup, QueueHandle_t gpsQueue);

// helpers for printing
void printAlertPayload(const AlertPayload& alert);

#endif
